package com.yash.actionform;

import org.apache.struts.action.ActionForm;

public class Department extends ActionForm{
	
	private int dept_id;
	private String dept_name;
	private String city;
	public int getDept_id() {
		return dept_id;
	}
	public void setDept_id(int dept_id) {
		this.dept_id = dept_id;
	}
	public String getDept_name() {
		return dept_name;
	}
	public void setDept_name(String dept_name) {
		this.dept_name = dept_name;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	@Override
	public String toString() {
		return "Dpartment [dept_id=" + dept_id + ", dept_name=" + dept_name + ", city=" + city + "]";
	}
	public Department(int dept_id, String dept_name, String city) {
		super();
		this.dept_id = dept_id;
		this.dept_name = dept_name;
		this.city = city;
	}
	
	public Department()
	{
		
	}
	

}
