package com.yash.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.LinkedList;
import java.util.List;

import com.yash.actionform.Department;

public class DepartmentDaoImpl implements DepartmentDao{
	
	@Override
	public List<Department> allDepartment() {
	Connection con =  MainConnection.getCon();
	List<Department> dept =new LinkedList<>(); 
		
		try
		{
			String query = "select * from department";
			PreparedStatement prt = con.prepareStatement(query);
			ResultSet set =  prt.executeQuery();
			while(set.next())
			{
				int id = set.getInt("dept_id");
				String name = set.getString("dept_name");
				String city = set.getString("city");
				dept.add(new Department(id,name,city));
			

			}
			System.out.println(dept.size());
		
			
			return dept;
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return dept;
		}
	
	}
}
