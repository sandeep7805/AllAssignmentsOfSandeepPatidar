package com.yash.dao;

import java.util.List;

import com.yash.actionform.Department;

public interface DepartmentDao {
	public List<Department> allDepartment();
}
