package com.yash.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.yash.actionform.Employee;
import com.yash.dao.EmployeeDaoImpl;

public class UpdateEmployee extends Action{

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		
		 	int id =Integer.parseInt(request.getParameter("id")); 
		 	String name=request.getParameter("name");
		 	String email= request.getParameter("email");
		 			String salary= request.getParameter("salary"); String age=
		 			request.getParameter("age");
		  
		 			System.out.println(name +"" + email + "" + id + ""+ "" + salary+ "" + age);
					
		 			  Employee emp = new Employee();
		 			  emp.setId(id);
		 			  emp.setName(name);
					  emp.setEmail(email);
					  emp.setSalary(salary);
					  emp.setAge(age);
					  

						
						  EmployeeDaoImpl employeeDaoImpl = new EmployeeDaoImpl();
						  employeeDaoImpl.updateEmployee(emp);
						 
					 
		 
		
		
		
		return mapping.findForward("success");
	}
	
	

}
