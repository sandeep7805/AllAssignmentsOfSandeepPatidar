package com.yash.dao;

import java.util.List;

import com.yash.actionform.Department;
import com.yash.actionform.Employee;

public interface EmployeeDao {

	
	public List<Employee> getAllEmployee();
	public void saveEmployee(Employee emp);
	public void deletEmployee(int id);
	public List<Employee> findByname(String name);
	public List<Employee> getAllEmployeeByID(int id);
	public void updateEmployee(Employee emp);
	
}
