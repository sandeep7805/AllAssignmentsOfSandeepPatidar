package com.yash.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.yash.actionform.Employee;
import com.yash.dao.EmployeeDaoImpl;

public class EmployeeReg extends Action{
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		Employee emp = (Employee)form;
		
		String name= request.getParameter("name");
		String email = request.getParameter("email");
		String salary = request.getParameter("salary");
		String age = request.getParameter("age");
		int deptid = Integer.parseInt(request.getParameter("deptid"));
		emp.setName(name);
		emp.setEmail(email);
		emp.setSalary(salary);
		emp.setAge(age);
		emp.setDept_id(deptid);
	
		
		EmployeeDaoImpl employeeDaoImpl= new EmployeeDaoImpl();
		employeeDaoImpl.saveEmployee(emp);
		return mapping.findForward("success");
	
	
		
		
	}
	

}
