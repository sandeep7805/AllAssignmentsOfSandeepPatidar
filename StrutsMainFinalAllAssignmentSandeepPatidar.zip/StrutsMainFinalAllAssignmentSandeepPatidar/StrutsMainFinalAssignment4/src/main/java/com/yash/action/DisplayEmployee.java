package com.yash.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.plaf.InternalFrameUI;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.yash.actionform.Employee;
import com.yash.dao.EmployeeDaoImpl;



public class DisplayEmployee extends Action{

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		
		 HttpSession session = request.getSession();
		
		int index = Integer.parseInt(request.getParameter("index")); 
		 session.setAttribute("index", index);
		
		
		EmployeeDaoImpl employeeDaoImpl = new EmployeeDaoImpl();
		List<Employee> emp = employeeDaoImpl.getAllEmployee();
		
		session.setAttribute("emp",emp);
		
		
		if(index == 0 )
		{
		
			
			return mapping.findForward("FirstAction");

		}
		
		
		
		
		else
		{
			return mapping.findForward("home");
		}
	
		
			
	}
	

}
