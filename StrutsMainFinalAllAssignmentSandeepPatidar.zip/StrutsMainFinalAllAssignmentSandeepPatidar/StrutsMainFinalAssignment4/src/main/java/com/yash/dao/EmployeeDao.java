package com.yash.dao;

import java.util.List;

import com.yash.actionform.Employee;

public interface EmployeeDao {

	
	public List<Employee> getAllEmployee(); 
	 public List<Employee> getAllEmployeeByID(int id);
	/*public void saveEmployee(Employeeemp);
	 * public void deletEmployee(int id); 
	 * public List<Employee> findByname(String name);
	 * public void updateEmployee(Employee emp); 
	 * public List<Employee> login(String email,String pass);
	 */
	
}
