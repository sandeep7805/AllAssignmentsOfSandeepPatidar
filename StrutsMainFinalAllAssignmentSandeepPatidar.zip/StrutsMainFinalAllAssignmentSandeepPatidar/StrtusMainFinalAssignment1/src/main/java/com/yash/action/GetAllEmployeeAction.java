package com.yash.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.yash.actionform.Employee;
import com.yash.dao.EmployeeDaoImpl;



public class GetAllEmployeeAction extends Action{
	
	
	
	
	
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
	try
	{
		
		EmployeeDaoImpl employeeDaoImpl = new EmployeeDaoImpl();
		request.setAttribute("employee", employeeDaoImpl.getAllEmployee());
		return mapping.findForward("success");
	}
		
	catch(Exception e)
	{
		e.printStackTrace();
		return mapping.findForward("home");
	}
	}
	
	

}
