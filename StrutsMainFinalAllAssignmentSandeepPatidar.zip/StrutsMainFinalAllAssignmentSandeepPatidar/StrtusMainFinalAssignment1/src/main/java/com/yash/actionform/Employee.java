package com.yash.actionform;

import org.apache.struts.action.ActionForm;

public class Employee extends ActionForm{
	
	private int id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	private String name;
	private String salary;
	private String email;
	private String age;
	
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public Employee(int id, String name, String salary, String email, String age) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.email = email;
		this.age = age;
	}
	
	public Employee()
	{
		
	}
	@Override
	public String toString() {
		return "Employee [" +"Id"+ id+ "name=" + name + ", salary=" + salary + ", email=" + email + ", age=" + age + "]";
	}
	
	
	
	
	

}
