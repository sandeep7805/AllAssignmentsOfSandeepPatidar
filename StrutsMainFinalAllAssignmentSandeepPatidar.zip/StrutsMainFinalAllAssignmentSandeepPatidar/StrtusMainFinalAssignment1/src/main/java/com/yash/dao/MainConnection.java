package com.yash.dao;

import java.sql.Connection;
import java.sql.DriverManager;



public class MainConnection {
	
	
	public static Connection getCon() 
	{
		Connection con = null;
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		String url = "jdbc:mysql://localhost:3306/StrutsMainAssig";
		String user = "root";
		String pass = "root";
		con = DriverManager.getConnection(url,user,pass);
		return con;
	}
	catch(Exception e)
	{
		e.printStackTrace();
		return con;
	}
	}


}
