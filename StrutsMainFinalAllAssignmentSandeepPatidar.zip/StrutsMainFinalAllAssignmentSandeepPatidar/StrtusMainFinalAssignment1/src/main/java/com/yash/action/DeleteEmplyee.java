package com.yash.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.yash.dao.EmployeeDaoImpl;

public class DeleteEmplyee extends Action {

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		String[] array = request.getParameterValues("id");
		
		EmployeeDaoImpl employeeDaoImpl = new EmployeeDaoImpl(); 
		for(String arrays:array)
		{
			int num =Integer.parseInt(arrays);
			employeeDaoImpl.deletEmployee(num);
		}
		
		
		
		return mapping.findForward("success");
	}
	
	

}
