package com.yash.actionform;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

public class Employee extends ActionForm{
	
	private int id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	private String name;
	private String salary;
	private String email;
	private String age;
	private String contact;
	
	
	
	
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public Employee(int id, String name, String salary, String email, String age,String contact) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.email = email;
		this.age = age;
		this.contact = contact;
	}
	
	public Employee()
	{
		
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + ", email=" + email + ", age=" + age
				+ ", contact = " +contact+   "]";
	}
	@Override
	public ActionErrors validate(ActionMapping mapping, HttpServletRequest request) {


		ActionErrors errors = new ActionErrors();
		String name= this.name;
		String nameSt ="[a-zA-Z]{5,60}";
		Pattern ptr =  Pattern.compile(nameSt);
		Matcher mt1 = ptr.matcher(name);
		 boolean nameValid 	 = mt1.matches();
		if(!nameValid)
		{
			errors.add("name",new ActionMessage("emp.form.name"));
		}
		
	
		
		
		String email = this.email;
		String emailRegx= "[a-zA-z0-9!@#$%^&*]{1,}@[g][m][a][i][l].[a-z]{2,3}$";
		Pattern ptr1 = Pattern.compile(emailRegx);
		Matcher mt2 = ptr1.matcher(email);
		boolean emaulvalid = mt2.matches();
		if(!emaulvalid)
		{
			errors.add("email",new ActionMessage("emp.form.email"));
		}
		
		String contact = this.contact;
		String contactregx = "[0-9]{10}"; 
		Pattern ptr3 = Pattern.compile(contactregx);
		Matcher mt3 = ptr3.matcher(contact);
		boolean contactValid = mt3.matches();
		if(!contactValid)
		{
			errors.add("contact",new ActionMessage("emp.form.contact"));
		}
		return errors;
	}
	
	
	
	
	
	

}
