package com.yash.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.mysql.cj.Session;
import com.yash.actionform.Employee;
import com.yash.dao.EmployeeDaoImpl;

public class LoginAction extends Action{

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
			String email = request.getParameter("email");
			String pass = request.getParameter("password");
			
			EmployeeDaoImpl employeeDaoImpl = new EmployeeDaoImpl();
			
			List<Employee> emp = employeeDaoImpl.login(email, pass);
			if(emp.size() > 0)
			{
				HttpSession empSession = request.getSession(true);
				empSession.setAttribute("email",email);
				empSession.setAttribute("password",pass);
				
				request.setAttribute("emp", emp);
				
				
				return mapping.findForward("success");
			}
			else
			{
				request.setAttribute("msg", "Enter valid deatils");
				return mapping.findForward("logout");
				
			}
			
			
		
	}
	

}
