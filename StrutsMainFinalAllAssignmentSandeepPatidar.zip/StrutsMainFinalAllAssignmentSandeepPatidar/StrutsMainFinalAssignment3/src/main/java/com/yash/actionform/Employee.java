package com.yash.actionform;

import org.apache.struts.action.ActionForm;

public class Employee extends ActionForm{
	
	private int id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	private String name;
	private String salary;
	private String email;
	private String age;
	private int dept_id; 
	private String password;
	
	
	
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getDept_id() {
		return dept_id;
	}
	public void setDept_id(int dept_id) {
		this.dept_id = dept_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public Employee(int id, String name, String salary, String email, String age,int dept_id,String password) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.email = email;
		this.age = age;
		this.dept_id = dept_id;
		this.password = password;
	}
	
	public Employee()
	{
		
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + ", email=" + email + ", age=" + age
				+ ", dept_id=" + dept_id + ", password=" + password + "]";
	}
	
	
	
	
	
	

}
