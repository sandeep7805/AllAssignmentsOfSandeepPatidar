package com.yash.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

import com.yash.actionform.Department;
import com.yash.actionform.Employee;

public class EmployeeDaoImpl implements EmployeeDao{

	@Override
	public List<Employee> getAllEmployee() {
		
	
		Connection con =  MainConnection.getCon();
		List<Employee> emp = new LinkedList<>();
		try
		{
		String query = "Select * from employee3";
		PreparedStatement prt = con.prepareStatement(query);
		ResultSet set =  prt.executeQuery();
		
		while(set.next())
		{
			int id = set.getInt("id");
			
			String name= set.getString("name");
			String salary = set.getString("salary");
			String email = set.getString("email");
			String age = set.getString("age");
			int dept_id = set.getInt("dept_id");
			String password = set.getString("password");
			emp.add(new Employee(id,name,salary,email,age,dept_id,password)); 
		
			
		}
		
		return emp;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return emp;
		}
		
		
		
	}

	@Override
	public List<Employee> getAllEmployeeByID(int id1) {
		
	
		Connection con =  MainConnection.getCon();
		List<Employee> emp = new LinkedList<>();
		try
		{
		String query = "Select * from employee1 where dept_id = ?";
		PreparedStatement prt = con.prepareStatement(query);
		prt.setInt(1, id1);
		ResultSet set =  prt.executeQuery();
		
		while(set.next())
		{
			int id = set.getInt("id");
			String name= set.getString("name");
			String salary = set.getString("salary");
			String email = set.getString("email");
			String age = set.getString("age");
			int dept_id = set.getInt("dept_id");
			String password = set.getString("password");
			emp.add(new Employee(id,name,salary,email,age,dept_id,password)); 
		
			
		}
		
		return emp;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return emp;
		}
		
		
		
	}

	@Override
	public void saveEmployee(Employee emp) {
		Connection con =  MainConnection.getCon();
	
		try
		{
			String query = "insert into employee(name,email,salary,age) values(?,?,?,?)";
			PreparedStatement prt = con.prepareStatement(query);
			prt.setString(1, emp.getName());
			prt.setString(2, emp.getEmail());
			prt.setString(3, emp.getSalary());
			prt.setString(4, emp.getAge());
			prt.executeUpdate();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		
		}
		
		
	}

	@Override
	public void deletEmployee(int id) {
		
		Connection con =  MainConnection.getCon();
		
		try
		{
			String query = "delete from employee where id = ?";
			PreparedStatement prt = con.prepareStatement(query);
			prt.setInt(1, id);
			prt.executeUpdate();
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		
		}
		
		
	}

	@Override
	public List<Employee> findByname(String name) {
		Connection con =  MainConnection.getCon();
		List<Employee> emp = new LinkedList<>();
		
		try
		{
			String query = "Select * from employee where name=?";
			PreparedStatement prt = con.prepareStatement(query);
			prt.setString(1, name);
			ResultSet set =  prt.executeQuery();
			
			while(set.next())
			{
				int id = set.getInt("id");
				
				String name1= set.getString("name");
				String salary = set.getString("salary");
				String email = set.getString("email");
				String age = set.getString("age");
				int dept_id = set.getInt("dept_id");
				String password = set.getString("password");
				emp.add(new Employee(id,name1,salary,email,age,dept_id,password)); 
			
				
			}
			
			return emp;
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return emp;
		}
		
		
	}

	@Override
	public void updateEmployee(Employee emp) {
		Connection con =  MainConnection.getCon();
		
	
		try
		{
			
			String query = "update employee1 set name=?,email=?,salary=?,age=? where id = ?";
			PreparedStatement prt = con.prepareStatement(query);
			prt.setString(1, emp.getName());
			prt.setString(2, emp.getEmail());
			prt.setString(3, emp.getSalary());
			prt.setString(4, emp.getAge());
			prt.setInt(5, emp.getId());
			prt.executeUpdate();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		
		}
		
	}

	@Override
	public List<Employee> login(String email, String pass) {
		
		Connection con =  MainConnection.getCon();
		List<Employee> emp = new LinkedList<>();
		
		try
		{
			String query = "Select * from employee3 where email=? and password = ?";
			PreparedStatement prt = con.prepareStatement(query);
			prt.setString(1, email);
			prt.setString(2, pass);
			ResultSet set =  prt.executeQuery();
			
			while(set.next())
			{
				int id = set.getInt("id");
				
				String name1= set.getString("name");
				String salary = set.getString("salary");
				String email1 = set.getString("email");
				String age = set.getString("age");
				int dept_id = set.getInt("dept_id");
				String password = set.getString("password");
				emp.add(new Employee(id,name1,salary,email1,age,dept_id,password)); 
			
				
			}
			
			return emp;
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return emp;
		
		}
		
		
	}



}
