class AThread implements Runnable
{
	public void run()
	{
		System.out.println("this is a Without Lemda Function");
	}
	}

public class LemdaExpDemo {
	public static void main(String[] args) {
		
		Thread tr = new Thread(new AThread());
		tr.start();
	}

}
