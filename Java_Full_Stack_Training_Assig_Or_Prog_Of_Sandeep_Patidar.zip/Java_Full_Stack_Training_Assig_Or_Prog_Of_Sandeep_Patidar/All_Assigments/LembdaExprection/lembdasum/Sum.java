package lembdasum;
public interface Sum
{
	public abstract int sum(int a,int b);
} 