import lembdasum.Sum;

class LembdaExprection implements Sum 
{
	//By Interface
	public int sum(int a,int b)
	{
			int add1 = a + b;
			System.out.println("Sum is = " + add1);
			return add1;
	}
	public static void main(String[] args)
	{
		
		//By Annonomyus Class 
			Sum s = new Sum()
			{
				public int sum(int a,int b)
				{
					int add = a + b;
					System.out.println("sum is = "+ add);
					return add;
				}		
			};
		s.sum(4,5);
		
		// By Interface 
		Sum s1= new LembdaExprection();
		s1.sum(5,7);
		
		//By Lembda Function
		Sum s2 = (4,5) -> 
		{
			int add ;
			System.out.println("Sum is = " + add);
			return add;
		};

	}
}

 