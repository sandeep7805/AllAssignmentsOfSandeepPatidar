	
public class LemdaExprDemo2  {

	
	public static void main(String[] args) {
		
		AInterface obj = (a , b) -> 
		{
			int add = a + b;
			return add;
		};

		System.out.println("sum is =" + obj.sum(4, 5));
		
		}
	}

