
public interface AInterface {

	public abstract int sum(int a,int b);
}
