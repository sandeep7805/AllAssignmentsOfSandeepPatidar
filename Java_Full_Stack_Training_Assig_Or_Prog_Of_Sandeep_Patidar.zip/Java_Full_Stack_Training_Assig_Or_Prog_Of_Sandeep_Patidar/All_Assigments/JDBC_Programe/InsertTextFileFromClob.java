
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.io.File;

import java.io.FileReader;
import java.sql.Clob;

public class InsertTextFileFromClob {

	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/test1";
			String user = "root";
			String pass = "root";
			Connection con = DriverManager.getConnection(url,user,pass);
			
			String s = "insert into employe(textfile) values(?)"; 
			
			PreparedStatement prps = con.prepareStatement(s);
			
			File f = new File("D://Spring_Tool_Suite//JdbcDemoAdvanceJava//abc.txt");
			FileReader fout =new FileReader(f);
			prps.setClob(1,fout);
			prps.executeUpdate();
			con.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
}








