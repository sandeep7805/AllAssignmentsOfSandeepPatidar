import java.sql.*;
public class JdbcDemo10
{
	public static void main(String[] args)
	{
		try
		{
		Class.forName("com.mysql.jdbc.Driver");
	
		
		String url  = "jdbc:mysql://localhost:3306/test1";
		String user = "root";
		String pass = "root";
		Connection con = DriverManager.getConnection(url,user,pass);
		
		String q = "Select * from employe";
		String q1 = "update name='abccccc' into employe where id=2";
		Statement st = con.createStatement();
		ResultSet set = st.executeQuery(q);
		ResultSet set2 = st.executeQuery(q1);
	 
		while(set.next())
		{
			int id = set.getInt("empId");
			String name = set.getString("name");
			System.out.println("Id is = " + id);
			System.out.println("Name is = " + name);
			
		}
		con.close(); }
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
}