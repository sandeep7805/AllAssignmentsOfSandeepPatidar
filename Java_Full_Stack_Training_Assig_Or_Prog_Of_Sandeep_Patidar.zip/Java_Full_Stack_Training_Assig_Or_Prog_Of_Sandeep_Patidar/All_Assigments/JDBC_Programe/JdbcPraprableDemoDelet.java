import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
public class JdbcPraprableDemoDelet  {

	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/test1";
			String user = "root";
			String pass = "root";
			
			Connection con = DriverManager.getConnection(url,user,pass);
			Statement st = con.createStatement();
			String s = "select * from employe";
			ResultSet set = st.executeQuery(s);
			while(set.next())
			{
				int id = set.getInt("empId");
				System.out.println("id is = " + id); 
				
			}
			String quary1 = "Delet into employe(empId,name) values(?,?)";
			PreparedStatement praps = con.prepareStatement(quary1);
			praps.setInt(1, 4);
			praps.setString(2, "abccccc");
			praps.executeUpdate();
			System.out.println(praps);
			
			while(set.next())
			{
				int id = set.getInt("empId");
				System.out.println("id is = " + id); 
				
			}
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
}


