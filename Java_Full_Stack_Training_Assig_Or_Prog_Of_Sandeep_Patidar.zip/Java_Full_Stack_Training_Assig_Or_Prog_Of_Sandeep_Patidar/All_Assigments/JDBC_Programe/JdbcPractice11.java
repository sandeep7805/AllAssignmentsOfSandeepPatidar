import java.sql.*;
class JdbcPractice11
{
	public static void main(String[] args){
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/test1";
			String user = "root";
			String pass = "root";
			
			Connection con = DriverManager.getConnection(url,user,pass);
			String quary = "insert into employe(empId,name) values(? , ?)";
			PreparedStatement prstmt = con.prepareStatement(quary);
			prstmt.setInt(1,99);
			prstmt.setString(2,"abcvcv");
			prstmt.executeUpdate();
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}