import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.io.InputStreamReader;
import java.nio.Buffer;
import java.io.BufferedReader;

public class JDBCUPADTEByConosl  {

	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/test1";
			String user = "root";
			String pass = "root";
			
			Connection con = DriverManager.getConnection(url,user,pass);
			Statement st = con.createStatement();
			String s = "select * from employe";
			ResultSet set = st.executeQuery(s);
			while(set.next())
			{
				int id = set.getInt("empId");
				System.out.println("id is = " + id); 
				
			}
			InputStreamReader ir = new InputStreamReader(System.in);
			BufferedReader br = new BufferedReader(ir);
			System.out.println("Enter the how many data you want to store ");
			int num = Integer.parseInt(br.readLine());
			String quary1 = "UPDATE employe SET name='?' where empId=?";
			PreparedStatement praps = con.prepareStatement(quary1);
			int i;
			for(i= 1; i<=num; i++ )
			{
				
				System.out.println("Enter Nmae of emp");
				String name = br.readLine();
				praps.setString(1,name);
				System.out.println("Enter the Id of emp");
				int id = Integer.parseInt(br.readLine());
				praps.setInt(2,id);
				
				
				praps.executeUpdate();
			}
		
		
			System.out.println(praps);
			
			
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
}


