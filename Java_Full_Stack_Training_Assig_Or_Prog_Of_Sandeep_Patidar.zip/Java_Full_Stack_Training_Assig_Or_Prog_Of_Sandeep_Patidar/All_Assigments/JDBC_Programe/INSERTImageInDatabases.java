import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.io.FileInputStream;

public class INSERTImageInDatabases {

	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/test1";
			String user = "root";
			String pass = "root";
			Connection con = DriverManager.getConnection(url,user,pass);
			
			String s = "insert into employe(image) values(?) "; 
			
			PreparedStatement prps = con.prepareStatement(s);
			
			FileInputStream finp = new FileInputStream("D://Spring_Tool_Suite//JdbcDemoAdvanceJava//Image1.png");
			prps.setBinaryStream(1, finp);
			prps.executeUpdate();
			con.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
}

