import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.*;

public class ImageImportfrodatabases{

	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/test1";
			String user = "root";
			String pass = "root";
			
			Connection con = DriverManager.getConnection(url,user,pass);
			String s = "Select image from employe where empId= 9";
			Statement st = con.createStatement();
			ResultSet set = st.executeQuery(s);
			while(set.next())
			{
				Blob b = set.getBlob("image");
				System.out.println("Image is = " + b);
			}
			
			con.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
}



