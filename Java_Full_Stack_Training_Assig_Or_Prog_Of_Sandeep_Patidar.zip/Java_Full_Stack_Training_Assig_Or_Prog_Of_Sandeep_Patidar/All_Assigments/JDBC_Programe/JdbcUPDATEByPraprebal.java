import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
public class JdbcUPDATEByPraprebal {

	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/test1";
			String user = "root";
			String pass = "root";
			
			Connection con = DriverManager.getConnection(url,user,pass);
			String quary1 = "UPDATE employe SET name='aaaaaac' WHERE empId=1 ";
			PreparedStatement praps = con.prepareStatement(quary1);
			praps.executeUpdate();
			System.out.println(praps);
			
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
}


