
import java.sql.*;

public class JdbcDemoOfMetaData
{
	public static void main(String[] args)
	{
		try{
			//load the driver
			Class.forName("com.mysql.jdbc.Driver");
			//Create connection
			String url = "jdbc:mysql://localhost:3306/test1";
			String user = "root";
			String pass = "root";
			Connection con = DriverManager.getConnection(url,user,pass);
			if(con != null)
			{
				System.out.println("Connection generate sucessfully");
			}
			else
			{
				System.out.println("Connection not generate ");
			}
			// create quary 
			String q = "select * from employe";
			Statement st = con.createStatement();
			ResultSet set = st.executeQuery(q);
			ResultSetMetaData setdata = set.getMetaData();
			
			// process data
			while(set.next())
			{
				int id = set.getInt("empId");// 1 (colomn name)
				String name = set.getString("name");
				
				
				System.out.println("Id is = " + id);
				System.out.println("Name is = " + name);
			
				
			}
				int totalColomn = setdata.getColumnCount();
				String colomnName1 = setdata.getColumnName(1);
				String colomType = setdata.getColumnTypeName(1);
				String tableName = setdata. getTableName(1);
				
				System.out.println("total colomn is = " + totalColomn);
				System.out.println("Colomn name at index 1  is = " + colomnName1);
				System.out.println("Colomn type  1 is = " + colomType);
				System.out.println("Table name of test1 database is = " + tableName);
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}

