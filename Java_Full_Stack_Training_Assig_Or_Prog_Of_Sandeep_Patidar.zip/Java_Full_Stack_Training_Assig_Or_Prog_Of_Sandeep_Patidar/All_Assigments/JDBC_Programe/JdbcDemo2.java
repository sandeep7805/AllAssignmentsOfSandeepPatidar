import java.sql.*;

class JdbcDemo2
{
	public static void main(String[] args)
	{
		try{
			//load the driver
			Class.forName("com.mysql.jdbc.Driver");
			//Create connection
			String url = "jdbc:mysql://localhost:3306/test1";
			String user = "root";
			String pass = "root";
			Connection con = DriverManager.getConnection(url,user,pass);
			if(con != null)
			{
				System.out.println("Connection generate sucessfully");
			}
			else
			{
				System.out.println("Connection not generate ");
			}
			// create quary 
			String q = "select * from employe";
			Statement st = con.createStatement();
			ResultSet set = st.executeQuery(q);
			
			// process data
			while(set.next())
			{
				int id = set.getInt("empId");// 1 (colomn name)
				String name = set.getString("name");
				System.out.println("Id is = " + id);
				System.out.println("Name is = " + name);
				
			}
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}