import java.sql.*;
import java.util.List;
import java.util.LinkedList;
import java.util.ListIterator;
class JdbcDemo9
{
	int id;
	String name;
	JdbcDemo9(int id,String name)
	{
		this.id = id;
		this.name = name;
	}
	public static void main(String[] args)
	{
		try
		{
			List l = new LinkedList();
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/test1";
			String user = "root";
			String pass = "root";
			Connection con = DriverManager.getConnection(url,user,pass);
			if(con != null )
			{
				System.out.println("Connection genarate ");
			}
			else
			{
				System.out.println("Connection Not genarate ");
			}
			String quary = "Select * from employe where empId=1";
			Statement st = con.createStatement();
			ResultSet set = st.executeQuery(quary);
			while(set.next())
			{
				int id1 = set.getInt("empId");
				String name1 = set.getString("name");
				System.out.println("id is = " + id1);
				System.out.println("Nmae is = " + name1);
				JdbcDemo9 obj = new JdbcDemo9(id1,name1);
				l.add(obj);
			}
			System.out.println();
			System.out.println("List is =" + l);
			ListIterator i1= l.listIterator();
			System.out.println("use ListItretor for itreat element from list");
			while(i1.hasNext())
			{
				JdbcDemo9 j = (JdbcDemo9)i1.next();
				System.out.println("Id is = " + j.id + " " + "Name is = " + j.name + " \n ");
			}
			
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}