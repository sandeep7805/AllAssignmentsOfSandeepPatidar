import javax.swing.*;
import java.util.Scanner;
class JOption
{
	public static void main(String[] args)
	{
		Scanner obj = new Scanner(System.in);
		JFrame f = new JFrame();
		System.out.println("enter  1 only  for massage box");
		int a = obj.nextInt();
		if(a == 1)
		{
			JOptionPane.showMessageDialog(f,"JOption is running ");
			System.exit(0);
		}		
	}

}