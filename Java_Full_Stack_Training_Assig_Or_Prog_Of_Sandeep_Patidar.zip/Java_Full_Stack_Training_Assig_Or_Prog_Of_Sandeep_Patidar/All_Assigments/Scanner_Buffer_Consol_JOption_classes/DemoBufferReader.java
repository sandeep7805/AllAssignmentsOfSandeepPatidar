import java.io.BufferedReader;
import java.io.InputStreamReader;
class DemoBufferReader
{	
	public static void main(String[] args)throws Exception
	{
		String s_name;
		String s_password;
		InputStreamReader i = new InputStreamReader(System.in);
		BufferedReader obj = new BufferedReader(i);
		System.out.println("Enter tha name ");
		s_name = obj.readLine();
		System.out.println("Enter tha Password ");
		s_password = obj.readLine();
		System.out.println("Entered name " + s_name);
		System.out.println("Entered name " + s_password);
		
		
	}
}