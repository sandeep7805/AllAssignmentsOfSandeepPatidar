import java.io.Console;

class DemoConsole
{
	public static void main(String args[])
	{
	char[] arry ;
	Console cs = System.console();
	System.out.println("Enter the name ");
	String s = cs.readLine();
	System.out.println("Enter the password");
	arry = cs.readPassword();
	System.out.println("Entered name is " + s);
	System.out.println("Entered password is =" + arry);
	String st = s.valueOf(arry);
	System.out.println("Password is = " + st);
	
	}
	
}