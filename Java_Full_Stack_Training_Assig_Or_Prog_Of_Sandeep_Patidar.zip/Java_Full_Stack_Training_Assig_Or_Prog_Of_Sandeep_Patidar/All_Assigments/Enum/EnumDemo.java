enum Directions
	{
		EAST,WEST,NORTH,SOUTH;
	}
class EnumDemo
{
		public static void main(String[] args)
		{
			Directions d = Directions.EAST;
			System.out.println(d);
		}		
}