class EnumSeasonDemo
{
	enum SEASON
	{
		SPRING,SUMMER,RAINY,WINTER;
		void constructor()
		{
			
		}
		SEASON()
			{
				System.out.println("valuse of  :" + SEASON.valueOf("SPRING"));
				System.out.println("Index of  :"+ SEASON.valueOf("SPRING").ordinal());
			
				System.out.println("valuse of  :" + SEASON.valueOf("SUMMER"));
				System.out.println("Index of  :"+ SEASON.valueOf("SUMMER").ordinal());
				
				System.out.println("valuse of  :" + SEASON.valueOf("RAINY"));
				System.out.println("Index of  :"+ SEASON.valueOf("RAINY").ordinal());
			
				System.out.println("valuse of  :" + SEASON.valueOf("WINTER"));
				System.out.println("Index of  :"+ SEASON.valueOf("WINTER").ordinal());
			}
	}
		public static void main(String[] args)
		{
		EnumSeasonDemo e= new EnumSeasonDemo();
		e.constructor();
		}		
}