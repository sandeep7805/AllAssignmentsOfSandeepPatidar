import java.util.Scanner;
class EnumWeekDayDemo
{
	enum WEEKDAYS
	{
		SUNDAY,MONDAY,TUESDAY,WEDNESDAY,THURSDAY,FRIDAY,SATURDAY;
	}
		public static void main(String[] args)
		{
			Scanner sc = new Scanner(System.in);
			int num;
			System.out.println("Enter the number etween 1 to 7");
			num = sc.nextInt();
			
			switch(num)
			{
				case 1:
				System.out.println("valuse of  :" + WEEKDAYS.valueOf("SUNDAY"));
				System.out.println("index is  :"+ WEEKDAYS.valueOf("SUNDAY").ordinal());
				break;
				case 2:
				System.out.println("valuse of  :" + WEEKDAYS.valueOf("MONDAY"));
				System.out.println("index is  :"+ WEEKDAYS.valueOf("MONDAY").ordinal());
				break;
				case 3:
				System.out.println("valuse of  :" + WEEKDAYS.valueOf("TUESDAY"));
				System.out.println("index is  :"+ WEEKDAYS.valueOf("TUESDAY").ordinal());
				break;
				case 4:
				System.out.println("valuse of  :" + WEEKDAYS.valueOf("WEDNESDAY"));
				System.out.println("index is  :"+ WEEKDAYS.valueOf("WEDNESDAY").ordinal());
				break;
				case 5:
				System.out.println("valuse of  :" + WEEKDAYS.valueOf("THURSDAY"));
				System.out.println("index is  :"+ WEEKDAYS.valueOf("THURSDAY").ordinal());
				break;
				case 6:
				System.out.println("valuse of  :" + WEEKDAYS.valueOf("FRIDAY"));
				System.out.println("index is :"+ WEEKDAYS.valueOf("FRIDAY").ordinal());
				break;
				case 7:
				System.out.println("valuse of  :" + WEEKDAYS.valueOf("SATURDAY"));
				System.out.println("index is  :"+ WEEKDAYS.valueOf("SATURDAY").ordinal());
				break;
				default:
					System.out.println("Enter number Between 1 to 7 ");
					break;
				
			}
			
			/*for(Directions d:Directions.values())
			{
				System.out.println(d);
			}
			
			System.out.println("valuse of  :" + Directions.valueOf("EAST"));
			System.out.println("valuse of  :"+ Directions.valueOf("EAST").ordinal());*/
		}		
}