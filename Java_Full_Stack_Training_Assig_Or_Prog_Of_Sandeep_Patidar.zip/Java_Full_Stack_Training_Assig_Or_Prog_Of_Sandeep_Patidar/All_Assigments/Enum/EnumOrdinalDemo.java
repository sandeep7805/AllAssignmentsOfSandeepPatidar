class EnumOrdinalDemo
{
	enum Directions
	{
		EAST,WEST,NORTH,SOUTH;
	}
		public static void main(String[] args)
		{
			for(Directions d:Directions.values())
			{
				System.out.println(d);
			}
			
			System.out.println("valuse of  :" + Directions.valueOf("EAST"));
			System.out.println("valuse of  :"+ Directions.valueOf("EAST").ordinal());
		}		
}