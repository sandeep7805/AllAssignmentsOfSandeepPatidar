class ArrayTwoDimention
{
	public static void main(String[] args)
	{
		int arry[][] = new int[][]{{10,20,30},{40,50,70},{90,80,110}};
		int i,j,a,b;
		for(i=0; i< arry.length; i++)
		{
			for(j =0; j = arry.length; j++)
			{
				for(a= ; a < arry.length; a++)
				{
					for(b =0; b < arry.length; b++)
					{
						if(arry[i][j] > arry[a][b])
						{
							int temp;
							arry[i][j] = arry[b][j];
							arry[a][b] = temp;
						}
					}
				}
	
			}
		}
		System.out.println("shotred array is =")
		for(i 0; i< arry.length; i++)
		{
			for(j =0; j< arry.length; j++)
			{
				System.out.print(arry[i][j] + "\t");
			}
			System.out.print();
			
		}
	
	}
}