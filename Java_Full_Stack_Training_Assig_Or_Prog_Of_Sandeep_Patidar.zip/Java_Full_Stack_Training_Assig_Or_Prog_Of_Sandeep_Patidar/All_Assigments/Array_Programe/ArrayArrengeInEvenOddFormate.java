import java.util.Scanner;
class ArrayArrengeInEvenOddFormate
{
	public static void main(String[] args)
	{
	
		int arry[] = new int[]{2,3,3,3,2,3,2,3,2,3,2,3,3};
		int i,j;
		for(i =0; i< arry.length; i++)
		{
			for(j =0; j< arry.length-1; j++)
			{
				if(arry[i]%2 == 0)
				{
					int temp = arry[i];
					arry[i] = arry[j];
					arry[j] = temp;
				}
			}
			
		}
		System.out.println("Array after the arreng is");
			for(i =0; i< arry.length; i++)
			{
				System.out.print(arry[i]);
			}
			System.out.println();
		
	}
}