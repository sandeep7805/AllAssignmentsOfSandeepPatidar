class FindFirstAndSecMaxAndMinElementInArray
{
	public static void main(String[] args)
	{
	int[] arry = new int[]{10,34,22,33,24,4,5,3};
	int temp =0,i,j;
	for(i =0; i< arry.length; i++)
	{
		for(j = i+1; j < arry.length; j++)
		{
			if(arry[i] > arry[j])
			{
				temp = arry[i];
				arry[i] = arry[j];
				arry[j] = temp;
			}
		}
	}
	System.out.println("First smallest number is =" + arry[0]);
	System.out.println("Second smallest number is =" + arry[1]);
	System.out.println("First Larger number is =" + arry[arry.length-1]);
	System.out.println("Second Larger number is =" + arry[arry.length-2]);

	}
}