class FindDuplicateElment
{
	public static void main(String[] args)
	{
		int arry[] = new int[]{2,4,5,3,4,3,4,5,2,5,7,9};
		int i,j,count=0;
		int arry1[] = new int[arry.length];
		for(i = 0; i< arry.length; i++)
		{
			for(j =0; j<arry.length-1; j++)
			{
				if(arry[i] < arry[j])
				{
					int temp = arry[i];
					arry[i] = arry[j];
					arry[j] = temp;
				}
			}
		}
		
		for(i = 0; i< arry.length; i++)
			{
				System.out.print(arry[i]);
			}
			
		System.out.println();
		
		for(i = 0; i< arry.length; i++)
			{
				for(j =0; j<arry.length-1; j++)
				{	
						if(arry[i] != arry[j])
						{
							arry1[i] = arry[i];
						}
						
				}
			}
		for(i = 0; i< arry1.length; i++)
		{
			System.out.print(arry1[i]);
		}
		
	}	
}