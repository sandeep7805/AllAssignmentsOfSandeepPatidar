class SumAndAvgOfTwoDimetionArray
{
	public static void main(String[] args)
	{
		int[][] arry = new int[][]{{10,20,30},{10,20,30},{10,20,30}};
		int sum =0,i,j,count=0;
		double avg;
		for(i =0; i<arry.length; i++)
		{
			for(j = 0; j<arry[i].length; j++)
			{
				sum = sum + arry[i][j];
				count++;	
			}
		}
		avg = sum /count;
		System.out.println("sum is =" + sum);
		System.out.println("avg is =" + avg);
	}
}