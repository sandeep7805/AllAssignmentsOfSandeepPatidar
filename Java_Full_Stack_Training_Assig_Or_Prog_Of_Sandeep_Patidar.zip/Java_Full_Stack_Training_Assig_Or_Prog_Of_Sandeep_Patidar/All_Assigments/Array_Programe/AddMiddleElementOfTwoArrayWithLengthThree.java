class AddMiddleElementOfTwoArrayWithLengthThree
{
	public static void main(String[] args)
	{
		int arry1[] = new int[]{10,20,30};
		int arry2[] = new int[]{10,20,30};
		
		int arry[] = new int[2];
		arry[0] = arry1[1];
		arry[1] = arry2[1];
		System.out.println("New Array is =");
		System.out.print(arry[0] + " " + arry[1]);
		
		
	}
}