class CheckOneorFourInArry
{
	public static void main(String[] args)
	{
		int arry[] = new int[]{1,1,1,1,1};
		int i,count=0;
		int var1 = 1, var2 = 4;
		for(i = 0; i < arry.length; i++)
		{
			if(arry[i]== var1 || arry[i]== var2)
			{	
				continue;	
			}
			else
			{
				count++;
			}
		}
		
		if(count<=0)
		{
			System.out.println("True");
		}
		else
		{
			System.out.println("False");
		}
	}
}