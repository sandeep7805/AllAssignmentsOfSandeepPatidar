class FindGreatestElementInTwoDimeArrayLangthOfArryIsThree
{	
	public static void main(String[] args)
	{
		int arry[][] = new int[3][3];
		int i,j,a,b;
		arry[0][0] = Integer.parseInt(args[0]);
		arry[0][1] = Integer.parseInt(args[1]);
		arry[0][2] = Integer.parseInt(args[2]);
		arry[1][0] = Integer.parseInt(args[3]);
		arry[1][1] = Integer.parseInt(args[4]);
		arry[1][2] = Integer.parseInt(args[5]);
		arry[2][0] = Integer.parseInt(args[6]);
		arry[2][2] = Integer.parseInt(args[8]);
		arry[2][1] = Integer.parseInt(args[7]);
		System.out.println("Entred Array is = ");
		for(i =0; i< 3; i++)
		{
			for(j = 0; j< 3; j++)
			{
				System.out.print(arry[i][j]  + "\t");
			}
			System.out.println();
		}
		
		for(i =0; i< 3; i++)
		{
			for(j = 0; j< 3; j++)
			{
					for(a =0; a< 3; a++)
					{
						for(b = 0; b< 3; b++)
						{
							if(arry[i][j] < arry[a][b])
							{
								int temp = arry[i][j];
								arry[i][j] = arry[a][b];
								arry[a][b] = temp;
							}
						}
					}	
			}
		}
		System.out.println("Shorted the Array is = ");
		for(i =0; i< 3; i++)
		{
			for(j = 0; j< 3; j++)
			{
				System.out.print(arry[i][j]  + "\t");
			}
			System.out.println();
		}
		
		System.out.println("Greatest Element is in Array =" + arry[2][2]);
	}
}