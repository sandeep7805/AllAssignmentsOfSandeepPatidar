class InArrayNumberIsPresentOrNot
{
	public static void main(String[] args)
	{
		int[] arry = new int[]{10,23,99,45,36,97};
		int num = Integer.parseInt(args[0]);
		int i;
		for(i = 0; i < arry.length; i++)
		{
			if(arry[i] == num)
			{
				System.out.println("index of number is =" + i);
				break;
			}
		}
		if(i+1 > arry.length)
		{
			System.out.println("-1");
		}
		
	}
}