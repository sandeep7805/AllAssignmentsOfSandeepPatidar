import java.util.Scanner;
class InvalidCountryException extends RuntimeException
{
	InvalidCountryException(String s)
	{
		super(s);
	}
}
class UserRegisterion
	{
		
		void userRegister(String u,String c,String check)
		{
			
			try
			{
				if (c.equals(check))
				{
					System.out.println("User registration sucessfull");
				}
				else
				{
					throw new InvalidCountryException("User outside india can not be register");
				}
			}
			catch(InvalidCountryException e)
				{
					e.printStackTrace();
				}
		
		}
		public static void main(String[] args)
			{
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter the userName");
			String username = sc.nextLine();
			System.out.println("Enter the userCountry");
			String userCountry = sc.nextLine();
			String checkCountry = "india";
			UserRegisterion obj = new UserRegisterion();
			obj.userRegister(username,userCountry,checkCountry);
				
			}
		
		
	}