class UseFinallyWithoutTryCatch
{
	public static void main(String[] args)
	{
		try
		{
			int a= 1000,b = 0, c;
			c = a/b;
		}
		finally
		{
			System.out.println("Finally block run");
		}
	}
	
}