import java.io.FileInputStream;
class ExceptionChecked
{
	public static void main(String[] args)
	{
		try 
		{
			FileInputStream f = new FileInputStream("D://xyz.txt");	
			// file not found checked
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
			//class.forname("com.mysql.jdbc.Driver");//class Not Found Exception(Checked)
	}
}