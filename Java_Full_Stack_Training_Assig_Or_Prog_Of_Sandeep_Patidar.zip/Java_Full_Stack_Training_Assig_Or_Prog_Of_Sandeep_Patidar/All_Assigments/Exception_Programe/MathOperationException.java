class MathOperationException
{
	public static void main(String[] args)
	{
		try
		{
			int num1 = Integer.parseInt(args[0]);
			int num2 = Integer.parseInt(args[1]);
			int num3 = Integer.parseInt(args[2]);
			int num4 = Integer.parseInt(args[3]);
			int num5 = Integer.parseInt(args[4]);
			int i,sum = 0;
			double avg;
			int arry[] = new int[5];
			arry[0] = num1;
			arry[1] = num2;
			arry[2] = num3;
			arry[3] = num4;
			arry[4] = num5;
			for(i =0; i< 5; i++)
			{
				sum = sum + arry[i];
			}
			avg = sum / 5;
			System.out.println("Sum of all elemrnt is = " + sum);
			System.out.println("Avg of all elemrnt is = " + avg);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("This is a catch block");
		}
	}
}