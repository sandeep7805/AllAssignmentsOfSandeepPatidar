class UseFinallyWithTryCatch
{
	public static void main(String[] args)
	{
		try
		{
			int a= 1000,b = 0, c;
			c = a/b;
		}
		catch(ArithmeticException e)
		{
			System.out.println(e.getMessage());
		}
		finally
		{
			System.out.println("Finally block run");
		}
	}
	
}