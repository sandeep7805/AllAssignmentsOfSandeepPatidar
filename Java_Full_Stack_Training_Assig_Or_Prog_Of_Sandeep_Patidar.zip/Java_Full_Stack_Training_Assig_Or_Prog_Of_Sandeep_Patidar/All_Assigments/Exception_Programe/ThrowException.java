import java.util.Scanner;
class VoteEligable extends RuntimeException 
{
	VoteEligable(String s)
	{
	super(s);
	}
}
class ThrowException
{
	public static void main(String[] args)
	{
		Scanner obj = new Scanner(System.in);
		System.out.println("Enter the age for vote");
		int age = obj.nextInt();
		try
		{
			if(age < 18)
			{
				throw new VoteEligable("Not eligible for vote");
			}
			else
			{
				System.out.println("Eligible for vote");
			}
		}
	
		catch(VoteEligable e)
		{
			e.printStackTrace();
		}
		System.out.println("Normal Termination");
	}
}