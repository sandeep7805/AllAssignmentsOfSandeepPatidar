import java.util.Scanner;
class ExceptionAssigArryOutOfBond2
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of arry");
		int size = sc.nextInt();
		int arry[] = new int[size]; 
		System.out.println("Enter the Element of array");
		int i;
		for(i = 0; i < size; i++)
		{
			int num = sc.nextInt();
			arry[i] = num;
		}
		try
		{
			System.out.println("Enter the index of Arry to find elemnt at position of index");
			int index = sc.nextInt();
			System.out.println(" elemnt at position of index " + index + " is = " + arry[index] );
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("Enter the right Index of arry ");
		}
	}	
}
