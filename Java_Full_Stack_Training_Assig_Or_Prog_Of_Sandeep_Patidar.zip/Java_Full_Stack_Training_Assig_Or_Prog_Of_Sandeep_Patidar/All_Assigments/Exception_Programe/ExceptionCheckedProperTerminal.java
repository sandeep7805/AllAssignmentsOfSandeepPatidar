import java.io.FileInputStream;
class ExceptionCheckedProperTerminal
{
	public static void main(String[] args)
	{
		try 
		{
			FileInputStream f = new FileInputStream("D://xyz.txt");	
			// file not found checked
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
			System.out.println("proper termination has done");
	}
}