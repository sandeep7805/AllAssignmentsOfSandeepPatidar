import java.io.FileInputStream;
import java.io.FileNotFoundException;
class ThrowsDemo
{
	void show() throws FileNotFoundException
	{
		FileInputStream f = new FileInputStream("d:/yash.txt");
	}
}
class ThrowsDemo2
{
	public static void main(String[] args)
	{
		ThrowsDemo t = new ThrowsDemo();
		try
		{
			t.show();
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		System.out.println("Normal Termination");
	}
}