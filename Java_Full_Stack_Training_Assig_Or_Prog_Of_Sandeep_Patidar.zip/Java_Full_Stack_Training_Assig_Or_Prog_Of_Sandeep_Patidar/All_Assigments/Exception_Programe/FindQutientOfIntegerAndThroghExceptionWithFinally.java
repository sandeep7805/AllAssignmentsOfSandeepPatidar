import java.util.Scanner;
class FindQutientOfIntegerAndThroghExceptionWithFinally
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number 1");
		int num1 = sc.nextInt();
		System.out.println("Enter the number 2");
		int num2 = sc.nextInt();
		try
		{
			int quotient = num1/num2;
			System.out.println("Quotient is = " + quotient);
			
		}
		catch(InvalidInteger e)
		{
			
			e.printStackTrace();
		}
		finally
		{
			System.out.println("Inside finally    block        ");
		}
	}
}
