class ExceptionDemoThrow
{
	public static void main(String[] args)
	{
		try
		{
		System.out.println("This is a Exception Demo Programe");
		System.out.println(100/0);
		throw ArithmeticException,NullPointerException;
		}
		catch(Exception e)
		{
			e.printStckTrace();
		}
	}
	
}