import java.util.Scanner;
class RangeException extends RuntimeException
{
	RangeException(String s)
	{
		super(s);
	}
}
class SumAndAvgOfStudentException
{
	public static void main(String[] args)
	{
	try{
		Scanner sc = new Scanner(System.in);
		System.out.println("Eneter the name of student");
		String st1 = sc.nextLine();
		System.out.println("Eneter the name of student2");
		String st2=sc.nextLine();
		int m_st1[] = new int[3];
		int m_st2[] = new int[3];
		int i,j,sum_1 =0,sum_2 =0;
		try{
			System.out.println("Eneter the marks of student 1");
			for(i =0; i< 3; i++)
			{
				int num = sc.nextInt();
				if(num >= 0 && num <= 100)
				{
					m_st1[i] = num;
					sum_1 = sum_1 + num;
					
				}
				else
				{
					throw new RangeException("Enter marks between 0 to 100");
					
				}
			}
			System.out.println("Eneter the marks of student  2");
			for(i =0; i< 3; i++)
			{
				int num = sc.nextInt();
				if(num >= 0 && num <= 100)
				{
					m_st2[i] = num;
					sum_2 = sum_2 + num;
					
				}
				else
				{
					throw new RangeException("Enter marks between 0 to 100");
				}
			}	
			
			double avg_1 = sum_1/3;
			double avg_2 = sum_2/3;
			System.out.println("Name of student 1 is " + st1);
			System.out.println("sum of student 1 is " + sum_1);
			System.out.println("avg of student 1 is " + avg_1);
			System.out.println();
			System.out.println("Name of student 2 is " + st2);
			System.out.println("sum of student 2 is " + sum_2);
			System.out.println("avg of student 2 is " + avg_2);
		}
		catch(RangeException e)
		{
			e.printStackTrace();
		}
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	}
}