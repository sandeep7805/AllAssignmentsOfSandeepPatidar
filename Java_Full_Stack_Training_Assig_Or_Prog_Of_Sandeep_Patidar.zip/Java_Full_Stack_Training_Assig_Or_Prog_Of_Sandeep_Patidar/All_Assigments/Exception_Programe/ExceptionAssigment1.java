class ExceptionAssigment1
{
	public static void main(String[] args)
	{
		try
		{
			int num = Integer.parseInt(args[0]);
			int squre = num*num;
			System.out.println("Squre of number is = " + squre);
		}
		catch(NumberFormatException e)
		{
			System.out.println("Enterd input is not a valid input ");
		}
		
	}
}