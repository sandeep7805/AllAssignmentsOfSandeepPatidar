class ExceptionCheckedClass
{
	public static void main(String[] args)
	{
		
		class.forname("com.mysql.jdbc.Driver");//class Not Found Exception(Checked)
	}
}