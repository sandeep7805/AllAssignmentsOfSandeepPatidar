import java.io.InputStreamReader;
import java.io.BufferedReader;
class ThrowsPrograme
{
	void A() throws Exception
	{
		InputStreamReader r = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(r);
		String name = br.readLine();
	}
}
class  ThrowsProgrameDemo
{
	public static void main(String[] args)
	{
		ThrowsPrograme obj = new ThrowsPrograme();
		try
		{
			obj.A();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		System.out.println("normal termination");
	}
}