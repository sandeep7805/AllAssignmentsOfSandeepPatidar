import java.io.FileInputStream;
import java.io.FileNotFoundException;
class ThrowsDemo
{
	void show() throws FileNotFoundException
	{
		FileInputStream f = new FileInputStream("d:/yash.txt");
	}
}