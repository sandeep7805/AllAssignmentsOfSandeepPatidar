import java.io.InputStreamReader;
import java.io.BufferedReader;
class ThrowsPrograme
{
	void A() throws Exception
	{
		InputStreamReader r = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(r);
		System.out.println("Enter the name ");
		String name = br.readLine(); // there IOException occure when we Do not use Throws
		
	}
}
class  ThrowsProgrameDemo
{
	public static void main(String[] args)
	{
		ThrowsPrograme obj = new ThrowsPrograme();
		
		//	obj.A(); there unreported Exception when do not use try catch
		try
		{
				obj.A();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		System.out.println("normal termination");
	}
}