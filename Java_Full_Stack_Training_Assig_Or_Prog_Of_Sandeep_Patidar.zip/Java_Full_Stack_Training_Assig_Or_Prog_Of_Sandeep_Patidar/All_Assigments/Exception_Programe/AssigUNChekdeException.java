import java.util.Scanner;
import java.util.InputMismatchException;
class AssigUNChekdeException 
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		try
		{
		int num1 = 10;
		int num2 = 0;
		System.out.println("divison of num is = " + num1/num2); // Arithemetic Exception
		}
		catch(ArithmeticException e)
		{
			e.printStackTrace();
		
		}
		try 
		{
			String s1=null;
			String s2="this";
			System.out.println(s1.concat(s2));
		}
		catch(NullPointerException e)
		{
			e.printStackTrace();
		}
		try
		{
			int arry[] = new  int[10];
			for(int i =0; i<=33; i++)
			{
				System.out.println(arry[i]);
			}
			
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			e.printStackTrace();
		}
		try
		{
			int a= Integer.parseInt(null);
			
				
		}
		catch(NumberFormatException e)
		{
			e.printStackTrace();
		}
		try
		{
			System.out.println("Enter String");
			int a=sc.nextInt();
			int b=sc.nextInt();
			int c=sc.nextInt();
			int sum = a + b + c;
			System.out.println("Enter the 5 then 2 then abc");
			
			
		}
		catch(InputMismatchException e)
		{
			e.printStackTrace();
		}
		
	
		
	}
}