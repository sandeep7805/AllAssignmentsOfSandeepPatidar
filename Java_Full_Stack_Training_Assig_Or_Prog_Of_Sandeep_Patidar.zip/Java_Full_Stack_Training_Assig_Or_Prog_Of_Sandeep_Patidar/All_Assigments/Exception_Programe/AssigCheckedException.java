import java.io.File;
import java.io.FileInputStream;

import java.io.InputStream;
import java.io.FileNotFoundException;

import java.io.ObjectInputStream;




class AssigCheckedException 
{
	public static void main(String[] args)  throws Exception
	{
		
		try
		{
		File f = new File("C:/Users/Sandeep.D/Desktop/FileIO/.txt");
		FileInputStream finput = new FileInputStream(f);
		int i ;
		while((i = finput.read()) != -1)
		{
			System.out.println((char)i);
		}
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		
		try
		{
		AssigCheckedException obj = new AssigCheckedException();
		FileInputStream finput = new FileInputStream("C:/Users/Sandeep.D/Desktop/FileIO/abc.txt");
		ObjectInputStream oos = new ObjectInputStream(finput);
		AssigCheckedException Aobj = (AssigCheckedException)oos.readObject();
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		
	}
}
