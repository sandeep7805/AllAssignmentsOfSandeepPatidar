class ArmstrongeNumber
{
	public static void main(String[] args)
	{
		int num = Integer.parseInt(args[0]);
		int i,temp=num,temp1 = num,rem,sum=0,count=0;
		
		while(temp!=0)
		{
			count++;
			temp = temp/10;
		}
		while(temp1 != 0 )
		{
			rem = temp1%10;
			sum = sum + (int)Math.pow(rem,count);
			temp1 = temp1 /10;
		}
		if(sum == num)
		{
			System.out.println("number is armstronge number = " + num );
		}
		else
		{
			System.out.println("number is not armstronge number = " + num );
		}
			
	}
}	