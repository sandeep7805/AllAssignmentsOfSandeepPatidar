class PrintSimpleTableOfAnyNumber
{
	public static void main(String[] args)
	{


		int a = Integer.parseInt(args[0]);
		int i;

		for (i =1; i<=10; i++)
		{
			int tab = a * i;
			System.out.println( a + " * " + i + " = " + tab );
		}

}
}