class PatternBasicTraiangle12
{
public static void main(String[] args)
{
	int row = Integer.parseInt(args[0]);
	int i,j;
	for(i = row; i>0; i--)
	{
		for(j = 1; j<=i; j++)
		{
			System.out.print(" * ");
		}
		System.out.println("");
	}
}
}