class Variable
{
	int a = 100; // instance variable
	static int b = 500; // static variable
	public void show()
		{
			int c; //local variable
			c = a + b;
			System.out.println("c is = " + c);
		}
	public static void main(String[] args)
	{
		Variable obj = new  Variable();
		obj.show();
	}
}