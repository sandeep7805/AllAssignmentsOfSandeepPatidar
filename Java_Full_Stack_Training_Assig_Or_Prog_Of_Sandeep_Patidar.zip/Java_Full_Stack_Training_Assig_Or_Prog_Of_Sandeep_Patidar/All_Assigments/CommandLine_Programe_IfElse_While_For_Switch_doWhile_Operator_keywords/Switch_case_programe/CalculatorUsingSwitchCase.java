class CalculatorUsingSwitchCase
{
	public static void main(String[] args)
		{
			char oprt;
			int a = Integer.parseInt(args[0]);
			int b = Integer.parseInt(args[2]);
	
			oprt = args[1].charAt(0);

		switch(oprt)
			{
				case '+':
					int sum = a + b;
					System.out.println("sum is =" + sum);
				break;

				case '-':
					int sub = a - b;
					System.out.println("sub is =" + sub);
				break;

				case '*':	
					int mul = a*b;
					System.out.println("mul is =" + mul);
				break;

				case '/':
					int div = a / b;
					System.out.println("sum is =" + div);
				break;

				case '%':
					int mod = a % b;
					System.out.println("sum is =" +mod);
				break;

				default:
				System.out.println("enetr the only + - * / %" );

}

}
}