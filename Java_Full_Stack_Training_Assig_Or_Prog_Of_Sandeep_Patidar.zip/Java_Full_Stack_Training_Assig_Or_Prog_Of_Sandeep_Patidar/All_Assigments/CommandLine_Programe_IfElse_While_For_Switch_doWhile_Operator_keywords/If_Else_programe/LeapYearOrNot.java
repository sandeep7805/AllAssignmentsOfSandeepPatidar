class LeapYearOrNot
{
	public static void main(String[] args)
	{
		int a = Integer.parseInt(args[0]);
		if(a % 4 == 0) 
			{
				if(a % 100 == 0)
				{	
					if (a % 400== 0) 
						System.out.println( a + "is leap year");
					else
						System.out.println( a + "is not leap year");
				}
				else
					System.out.println( a + "is leap year");
			}
		else
			System.out.println( a + "is not leap year");
	}
}