class PrimeNumberBetweenTwoNumberAndSum
{
	public static void main(String[] args)
		{
		int num = Integer.parseInt(args[0]);
		int num1 = Integer.parseInt(args[1]);

		int count,sum =0;	

		for (int i = num; i <= num1; i++)
			{
				int temp = num;
				count = 0;
				for (int j = 2; j <= i / 2; j++) 
				{
					if (i % j == 0) 
					{
						count++;
						break;
					}
				}
				if (count == 0) {
					System.out.println(i);
			sum = sum + i;
		}
	}
	System.out.println("sum is = " + sum);
}
}