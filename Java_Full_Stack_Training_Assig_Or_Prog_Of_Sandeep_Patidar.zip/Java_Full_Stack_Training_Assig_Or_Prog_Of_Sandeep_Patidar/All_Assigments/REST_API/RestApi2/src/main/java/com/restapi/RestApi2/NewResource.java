package com.restapi.RestApi2;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("tresource")
public class NewResource {
	@GET
	@Produces(MediaType.APPLICATION_ATOM_XML)
	public Resource getResource()
	{
		Resource obj = new Resource();
		obj.setId(1);
		obj.setName("Abc");
		return obj;
		
	}
	
}
