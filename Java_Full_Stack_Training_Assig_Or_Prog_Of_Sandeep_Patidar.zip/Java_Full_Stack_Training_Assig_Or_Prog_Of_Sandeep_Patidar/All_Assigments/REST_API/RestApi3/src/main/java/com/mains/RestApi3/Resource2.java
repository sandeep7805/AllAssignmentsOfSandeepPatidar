package com.mains.RestApi3;


import java.util.LinkedList;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.message.internal.HttpHeaderReader;

@Path("/abc")
public class Resource2 {
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String get()
	{
		return "This is a res api 3";
	}
	@GET
	@Path("/jason")
	@Produces(MediaType.TEXT_PLAIN)
	public String get1()
	{
		return "This is a res api 3";
	}
	
	@GET
	@Path("/user")
	@Produces(MediaType.APPLICATION_XML)
	public Resource1 resources()
	{
		Resource1 obj = new Resource1();
		obj.setId(1);
		obj.setName("abc");
		
		return obj;
	}

}
