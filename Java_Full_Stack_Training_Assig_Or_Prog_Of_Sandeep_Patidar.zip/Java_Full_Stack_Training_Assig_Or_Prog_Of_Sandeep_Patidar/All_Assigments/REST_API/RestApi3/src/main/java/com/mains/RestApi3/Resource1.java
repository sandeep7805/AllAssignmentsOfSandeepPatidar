package com.mains.RestApi3;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Resource1 {

	@XmlElement
	private int id;
	@XmlElement
	private String name;
	public Resource1(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	public Resource1()
	{
		
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}


}
