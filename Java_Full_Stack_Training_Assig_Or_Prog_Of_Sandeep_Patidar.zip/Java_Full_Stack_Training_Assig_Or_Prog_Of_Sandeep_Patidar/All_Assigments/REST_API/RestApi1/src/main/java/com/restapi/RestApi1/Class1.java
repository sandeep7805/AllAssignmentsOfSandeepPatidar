package com.restapi.RestApi1;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/class1")
public class Class1 {
	
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String class1()
	{
		return "In class function";
	}
	

}
