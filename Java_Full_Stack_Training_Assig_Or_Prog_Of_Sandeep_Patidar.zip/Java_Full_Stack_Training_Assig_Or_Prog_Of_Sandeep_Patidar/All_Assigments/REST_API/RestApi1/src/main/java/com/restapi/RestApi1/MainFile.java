package com.restapi.RestApi1;



import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.jvnet.hk2.annotations.Service;

@Path("myresource")
public class MainFile {

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	  public String getIt1()
	    {
	    	String s ="This is a Stirn function";
	    
	    	return s;
	    	 }
	
}
