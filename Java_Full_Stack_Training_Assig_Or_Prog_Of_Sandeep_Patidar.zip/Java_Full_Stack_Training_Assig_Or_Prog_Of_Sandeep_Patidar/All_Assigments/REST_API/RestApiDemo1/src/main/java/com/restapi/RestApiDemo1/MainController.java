package com.restapi.RestApiDemo1;

import java.lang.annotation.*;
import java.util.List;

import com.restapi.RestApiDemo1.Dao.EmpDao;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;


@Path("/main")
public class MainController {
	
	EmpDao obj = new EmpDao();
	
	@GET
	@Path("/users")
	@Produces(MediaType.APPLICATION_XML)
	public List<EmpDao> getUser()
	{
		
		return obj.list1();
		
	}
	
	

}
