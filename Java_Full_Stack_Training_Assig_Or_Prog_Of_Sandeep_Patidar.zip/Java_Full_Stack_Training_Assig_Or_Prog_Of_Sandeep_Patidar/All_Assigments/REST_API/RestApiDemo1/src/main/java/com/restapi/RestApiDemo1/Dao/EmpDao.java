package com.restapi.RestApiDemo1.Dao;

import java.util.LinkedList;
import java.util.List;

import jakarta.ws.rs.Path;


public class EmpDao {
	
	List<Emp>  list = new LinkedList();
	
	public List list1()
	{
		list.add(new Emp(1,"sandeep","90000000"));
		list.add(new Emp(2,"sandeep2","90000000"));
		list.add(new Emp(3,"sandeep3","90000000"));
		list.add(new Emp(4,"sandeep4","90000000"));
		list.add(new Emp(5,"sandeep5","90000000"));
		return list;
	}
	
}
