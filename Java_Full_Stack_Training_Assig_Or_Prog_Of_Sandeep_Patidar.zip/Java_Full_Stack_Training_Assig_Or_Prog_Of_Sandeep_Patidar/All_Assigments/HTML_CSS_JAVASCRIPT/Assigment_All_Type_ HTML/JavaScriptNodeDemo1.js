var a= 10;
consol.log("a is " + a);