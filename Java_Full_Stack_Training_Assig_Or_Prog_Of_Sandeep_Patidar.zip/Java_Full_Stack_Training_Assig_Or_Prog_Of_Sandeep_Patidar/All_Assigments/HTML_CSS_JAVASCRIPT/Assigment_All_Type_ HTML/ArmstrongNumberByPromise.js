function func1()
{
    return new Promise(function(resolve,reject)
    {
        setTimeout(function()
        {
            
            const error = false;
            if(!error)
            {
                resolve();
           
            }
            else
            {
                reject();
               
            }
        },1000);
    })
    
}

function armstrong()
{
var num = 153;
var count = 0;
var sum =0;
var temp = num;
var temp1 = num;

while(num !=0 )
{
    num = parseInt(num/10);
    count = count + 1;
}
while(temp != 0)
{
    rem = parseInt((temp % 10));
    sum = parseInt(sum + (rem**count));
    temp = parseInt(temp/10); 
}
if(sum == temp1)
{
    console.log("Number is armstronge" + temp1) ;  
}
else
{
    console.log("Number is not armstronge" + temp1) ;  
}
}

func1().then(armstrong()).catch( function(){ console.log("This is catch block")});


