function func1()
{
    return new Promise(function(resolve,reject)
    {
        setTimeout(function()
        {
            
            const error = true;
            if(!error)
            {
                resolve();
           
            }
            else
            {
                reject();
               
            }
        },1000);
    })
    
}

function string()
{

var s = "aacbcaa";
var arry = new Array();
arry = s.split(''); 


console.log("s is " + s);
console.log("array is " + arry);

var s1 = arry.reverse();
console.log("s1 is " + s1);

var s3 = s1.join('');
console.log("s3 is " + s3);

if(s == s3)
{
    console.log("Sring is in palindrome");
}
else
{
    console.log("Sring is not in palindrome");
}
}


func1().then(string()).catch( function(){ console.log("This is catch block")});
