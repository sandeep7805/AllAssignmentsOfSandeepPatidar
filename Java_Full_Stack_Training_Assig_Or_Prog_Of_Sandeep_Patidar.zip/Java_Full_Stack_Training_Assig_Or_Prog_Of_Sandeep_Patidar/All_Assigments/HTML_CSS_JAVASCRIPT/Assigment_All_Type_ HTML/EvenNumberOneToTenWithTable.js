var i;
var array = new Array(); 
for(i =1; i<=10; i++ )
{
    if( i%2 == 0)
    {
        let t;
        
        for(t = 1; t <=10; t++)
        {
            
            console.log(i + "*" + t + "=" + (t*i));
        }
        console.log("__________________________________________________________________________________________")
    array.push(i);
    }
}
console.log("All even number 1 to 10");
var v;
for(v =0; v < array.length; v++ )
{
     
    console.log(array[v] + "\t");
}