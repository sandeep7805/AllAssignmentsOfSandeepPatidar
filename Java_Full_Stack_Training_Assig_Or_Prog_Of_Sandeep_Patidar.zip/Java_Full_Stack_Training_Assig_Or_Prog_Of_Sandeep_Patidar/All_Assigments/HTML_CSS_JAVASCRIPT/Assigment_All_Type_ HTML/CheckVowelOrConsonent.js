var s = "aeiouth";
var array = new Array();
array = s.split('');
var i;
var vowel =0;
var consonent =0;


for(i =0; i <array.length; i++)
{
    if(array[i] == 'A' ||array[i] == 'E'||array[i] == 'I' ||array[i] == 'O'||array[i] == 'U'||array[i] == 'a' || array[i] == 'e' || array[i] == 'i' || array[i] == 'o' || array[i] == 'u')
    {
     
        vowel = vowel +1;
    }
    else if(array[i] >= 'a' && array[i] <= 'z')
    {
     consonent = consonent + 1;   
    }
    else if(array[i] >= '0' && array[i] <= '9')
    {
        continue;
    }
    
    if(array[i]==' ')
    {
        continue;
    }
  
}


console.log("vowel is "+ vowel);
console.log("consonent is " + consonent );
