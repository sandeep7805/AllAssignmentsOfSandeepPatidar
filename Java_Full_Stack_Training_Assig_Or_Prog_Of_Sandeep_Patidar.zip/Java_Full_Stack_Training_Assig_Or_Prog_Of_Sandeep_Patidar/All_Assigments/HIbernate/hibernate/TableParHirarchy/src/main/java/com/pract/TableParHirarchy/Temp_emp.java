package com.pract.TableParHirarchy;

import javax.persistence.*;

@Entity
@DiscriminatorValue("Temp_Emp")
public class Temp_emp extends Employee{


	@Column(name="pay_par_hour")
	private int pay_pr_hour;
	
	@Column(name="duration")
	private int duration;
	
	public int getPay_pr_hour() {
		return pay_pr_hour;
	}
	public void setPay_pr_hour(int pay_pr_hour) {
		this.pay_pr_hour = pay_pr_hour;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}

	public Temp_emp(int pay_pr_hour, int duration) {
		super();
		this.pay_pr_hour = pay_pr_hour;
		this.duration = duration;
	}
	public Temp_emp() {
	
	}
}
