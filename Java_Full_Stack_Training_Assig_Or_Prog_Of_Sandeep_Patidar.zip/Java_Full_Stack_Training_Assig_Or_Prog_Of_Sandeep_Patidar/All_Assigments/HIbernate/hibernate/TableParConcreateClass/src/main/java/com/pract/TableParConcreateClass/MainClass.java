package com.pract.TableParConcreateClass;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class MainClass {

	public static void main(String[] args) {
		

	StandardServiceRegistry str = new StandardServiceRegistryBuilder().configure("hiber.cfg.xml").build();
	Metadata meta = new MetadataSources(str).getMetadataBuilder().build();
	
	SessionFactory  sfactory = meta.getSessionFactoryBuilder().build();
	Session s = sfactory.openSession();
	Transaction t = s.beginTransaction();
	
	
	Emp1 e= new Emp1();
	e.setName("abc");
	
	Reg_Emp e1 = new Reg_Emp();
	e1.setName("abc1");
	e1.setId(1);
	e1.setSalary(9000000);
	e1.setBonus(70000);
	
	Temp_Emp e2 = new Temp_Emp();
	e2.setId(1);
	e2.setName("abc2");
	e2.setPay_pr_hour(90000);
	e2.setWork_hour(9);
	
	

	s.save(e);
	s.save(e1);
	s.save(e2);
	
	t.commit();
	s.close();
	
	
	}
}
