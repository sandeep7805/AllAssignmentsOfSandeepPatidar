package com.mvc.HibernateAssignment1;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class EmpDao {

	public static void main(String[] args) {
		
		
		StandardServiceRegistry sregistry =new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
		Metadata meta = new MetadataSources(sregistry).getMetadataBuilder().build();
		SessionFactory sFactory = meta.buildSessionFactory();
		
		Session s = sFactory.openSession();
		Transaction t = s.beginTransaction();
		
		Employee e = new Employee();
		e.setId(1);
		e.setName("employee1");
		e.setSalary("9000000");
		
		s.save(e);
		t.commit();
		s.close();
		
		
	}
}
