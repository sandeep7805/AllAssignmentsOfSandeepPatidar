package com.hibernate.HibernateAssignment2InserEmplloyeeByAnnotationClass;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class EmployeeDao {

	public static void main(String[] args) {
		
		StandardServiceRegistry sRegister = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
		Metadata meta = new MetadataSources(sRegister).getMetadataBuilder().build();
		SessionFactory sFactory = meta.getSessionFactoryBuilder().build();
		
		Session s = sFactory.openSession();
		Transaction t = s.beginTransaction();
		
		Employee e  = new Employee();
		e.setId(1);
		e.setName("employee99");
		e.setSalary("9099000");
		s.save(e);
		t.commit();
		s.close();
		sFactory.close();
		
	}
}
