package com.jsp;

public class Servlet {

}
