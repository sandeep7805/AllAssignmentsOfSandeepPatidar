import java.util.ArrayList;
import java.util.Iterator;


class Assig1ArryListMonth
{public static void main(String[] args)
	{
		ArrayList<String> a = new ArrayList<String>();
		
		a.add("January");
		a.add("February ");
		a.add("March");
		a.add("April ");
		a.add("May");
		a.add("June ");
		a.add("July");
		a.add("August");
		a.add("September");
		a.add("October");
		a.add("November");
		a.add("December ");
		int i;
		System.out.println("This by indexing");
		for(i =0; i <= 11; i++)
		{
		System.out.println("At Index "+ i + "Value is = " + a.get(i));
		}
		System.out.println();	
		Iterator ir = a.iterator();
		System.out.println();
		System.out.println("By ForEach loop");
		for(String t:a)
		{
			System.out.print(t+ "\t");
		}
		System.out.println();
		System.out.println("By Itretive loop");
		while(ir.hasNext())
		{
			System.out.println(ir.next());
		}
		System.out.println();
		System.out.println(a.size());
	}
	
}