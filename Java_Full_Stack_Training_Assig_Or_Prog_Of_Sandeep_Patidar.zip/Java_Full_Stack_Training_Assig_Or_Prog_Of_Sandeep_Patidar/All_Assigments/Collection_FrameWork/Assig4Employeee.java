import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.util.Enumeration;
import java.util.Vector;
import java.util.Collections;
class Assig4Employeee
{	
	int id;
	String name;
	int salary;

	Assig4Employeee(int id,String name ,int salary)
	{
		this.id = id;
		this.name = name;
		this.salary = salary;
	}
	public static void main(String[] args) throws Exception
	{
	InputStreamReader ir = new InputStreamReader(System.in);
	BufferedReader br = new BufferedReader(ir);
	Vector<Object> v = new Vector<Object>();
	System.out.println("Enter the Number of Employee");
	int size = Integer.parseInt(br.readLine());
	int i;
	for(i=1; i <= size; i++)
	{
		System.out.println("Enter the id");
		int id= Integer.parseInt(br.readLine());
		
		System.out.println("Enter the name");
		String name = br.readLine();
		
		System.out.println("Enter the salary");
		int salary = Integer.parseInt(br.readLine());
		
		Assig4Employeee obj = new Assig4Employeee(id,name,salary);
		v.add(obj);
		
	}
	System.out.println("Employe Deatails print by Enumartion Method");
	
	Enumeration er = Collections.enumeration(v);
	while(er.hasMoreElements())
	{
		Assig4Employeee e = (Assig4Employeee)er.nextElement();
		
		System.out.println(" \t\t Id is = " + e.id);
		System.out.println(" \t\t Name is = " + e.name);
		System.out.println(" \t\t Salary is = " + e.salary);
		System.out.println();
		
		
	}
	}	
}