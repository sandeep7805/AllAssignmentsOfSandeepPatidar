
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class ItretiveForEachDemo  {

	public static void main(String[] args) 
	{
		ArrayList<Object> a = new ArrayList<>();
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the elements ");
		for(int i=0 ;i <=3; i++)
		{
			int num = sc.nextInt();
			a.add(num);
		}
		System.out.println("Enetr the string");
		for(int i=0 ;i <=3; i++)
		{
			String s = sc.nextLine();
			a.add(s);
		}
		System.out.println("This is a Example of For Each Loop ");
		for(Object i:a)
		{
			System.out.print("Element is =" + i + "\t");
		}
		System.out.println("This is a Example of  iterator Loop ");
		Iterator ir = a.iterator();
		while(ir.hasNext())
		{
			System.out.println(ir);
		}
	}
}
