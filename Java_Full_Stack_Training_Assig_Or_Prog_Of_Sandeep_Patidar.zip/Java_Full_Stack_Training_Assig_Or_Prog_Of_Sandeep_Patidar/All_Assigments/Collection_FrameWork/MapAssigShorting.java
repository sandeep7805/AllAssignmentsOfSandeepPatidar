import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import java.util.Iterator;
class MapAssigShorting
{
	public static void main(String[] args)
	{
		Map<Integer,String> mp = new HashMap<Integer,String>();
		mp.put(1,"one");
		mp.put(5,"Three");
		mp.put(9,"Three");
		mp.put(3,"Three");
		mp.put(2,"Two");
		mp.put(3,"Three");
		mp.put(4,"Three");
	
		
		Iterator i = mp.keySet().iterator();
		while(i.hasNext())
		{
			int num = (int)i.next();
			System.out.println("key is = " + num + "   Value is =  " + mp.get(num));
		}
		
		
		
		
	}
}