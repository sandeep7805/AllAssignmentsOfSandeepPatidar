import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

import java.util.Iterator;

public class MapData {
	MapData(int i1,String name)
	{

	}
 public static void main(String[] args) throws Exception{
	 
	Scanner sc = new Scanner(System.in);
	Scanner sc1 = new Scanner(System.in);
	
    List<Object> h = new LinkedList<>();
    int i;
    for(i = 1; i<=3; i++)
    {
    	System.out.println("Enter the number");
    	int i1 = sc.nextInt();
    	String name = sc1.nextLine();
    	h.add(new MapData(i1,name));
    	}
    Iterator ih = h.iterator();
    while(ih.hasNext())
    {
    	MapData t = (MapData)ih.next();
    	System.out.println(t.toString());t
    }
    
    }
}