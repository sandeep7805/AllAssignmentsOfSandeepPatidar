import java.util.HashSet;
class HashSetsDemo
{
	public static void main(String[] args)
	{
		HashSet<String> hs = new HashSet<String>();
		hs.add("Abc");
		hs.add("Abcc");
		hs.add("Abccc");
		hs.add("Abcc");
		hs.add("Abccc");
		hs.add("Abcccc");
		for(String i: a)
		{
			System.out.println(a);
		}
		
	}
}