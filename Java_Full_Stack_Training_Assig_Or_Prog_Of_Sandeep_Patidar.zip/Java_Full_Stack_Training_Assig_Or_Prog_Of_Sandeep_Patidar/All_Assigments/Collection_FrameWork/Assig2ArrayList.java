import java.util.ArrayList;
import java.util.Iterator;

class Assig2ArrayList
{
	public static void main(String[] args) throws Exception 
	{
		
		
		ArrayList<Number> a = new ArrayList<Number>();
		a.add(1000);
		a.add(100.0098989D);
		a.add(11121313123L);
		
		Iterator ir = a.iterator();
		while(ir.hasNext())
		{
				System.out.println(ir.next());
		}
	}
}