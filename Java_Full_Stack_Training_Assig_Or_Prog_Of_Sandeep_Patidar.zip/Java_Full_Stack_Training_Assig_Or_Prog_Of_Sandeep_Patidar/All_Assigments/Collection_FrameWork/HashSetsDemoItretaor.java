import java.util.HashSet;
import java.util.Iterator;

class HashSetsDemoItretaor
{
	public static void main(String[] args)
	{
		HashSet<String> hs = new HashSet<String>();
		hs.add("Abc");
		hs.add("Abcc");
		hs.add("Abccc");
		hs.add("Abcc");
		hs.add("Abccc");
		hs.add("Abcccc");
		for(String i:hs)
		{
			System.out.print(i + "\t");
		}
		System.out.println();
		System.out.println("This is by Itretive ");
		Iterator i= hs.iterator();
		while(i.hasNext())
		{
			System.out.print(i.next() + "\t");
			
		}
		System.out.println();
		System.out.println("Size of hash = " + hs.size());
		i.remove();
		System.out.println();
		for(String t:hs)
		{
			System.out.print(t + "\t");
		}
		
		
		System.out.println();
		System.out.println("Size of hash = " + hs.size());
		System.out.println();
		System.out.println("Hash Contains Abcc  = " + hs.contains("Abcc"));
		System.out.println();
		System.out.println("HashSet is Empty  = " + hs.isEmpty());
		System.out.println();
		hs.clear();
		
	
		
	}
}