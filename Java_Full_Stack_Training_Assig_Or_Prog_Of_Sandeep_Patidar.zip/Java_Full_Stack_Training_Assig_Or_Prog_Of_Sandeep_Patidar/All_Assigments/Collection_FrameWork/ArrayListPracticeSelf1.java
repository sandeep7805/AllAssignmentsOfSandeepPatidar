import java.util.ArrayList;
import java.util.Scanner;
class ArrayListPracticeSelf1
{
	String st1;
	String st;
	ArrayListPracticeSelf1(String st1,String st)
	{
		this.st1 = st1;
		this.st = st;
	}
	public static void main(String[] args)
	{
		
		ArrayList arraylist = new ArrayList();
		arraylist.add(10);
		arraylist.add(10);
		arraylist.add("t");
		arraylist.add(10.0000);
		arraylist.add(true);
		arraylist.add(9989989L);
		arraylist.add("This is a java");
		arraylist.add('f');
		arraylist.add(100);
		arraylist.add(1000000);
		System.out.println(arraylist);
		Scanner sc = new Scanner(System.in);
		int i;
		for(i = 1; i<=3;i++)
		{
			System.out.println("Enter the String");
			String st1 = sc.nextLine();
			System.out.println("Enter the String");
			String st = sc.nextLine();
			ArrayListPracticeSelf1 a1 = new ArrayListPracticeSelf1(st1,st);
			arraylist.add(a1);
		}
		System.out.println("After adding String ");
		System.out.println(arraylist);
		System.out.println(arraylist.contains(10));
		arraylist.remove(4);
		System.out.println(arraylist);
		
		
	}
	
}