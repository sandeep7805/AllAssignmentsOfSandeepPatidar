import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

class A<K, V>
{
	Map<String, String> M1 =new  HashMap<String,String>();
	String Country_Name;
	String capital_Name;
	private Map<String, String> map;
	private Object value;
	String saveCountryCapital(String Country_Name, String capital_Name)
	{
		this.Country_Name = Country_Name;
		this.capital_Name = capital_Name;
		M1.put(Country_Name, capital_Name);
		
		return Country_Name + capital_Name;
	}
	String getCaptial(String Country_Name)
	{
		String capital_Name = M1.get(Country_Name);
		return capital_Name;
	}
	String getCountry(String capital_Name)
	{
		 String captial_Name;
				for (Entry<String, String> entry: M1.entrySet())
		        {
					this.capital_Name = capital_Name;
					value =capital_Name;
					if (value.equals(entry.getValue())) {
		                return entry.getKey();
		            }
		        }
		        return null;
	}
	
}



public class Assig4CountryCaptial extends A
{
	public static void main(String[] args) {
		
		Assig4CountryCaptial obj = new Assig4CountryCaptial();
		obj.saveCountryCapital("India", "Abc");
		System.out.println();
		String t = obj.getCaptial("India");
		System.out.println(t);
		System.out.println();
		String tt = obj.getCountry("Abc");
		System.out.println(tt);
		
		
	}

}
