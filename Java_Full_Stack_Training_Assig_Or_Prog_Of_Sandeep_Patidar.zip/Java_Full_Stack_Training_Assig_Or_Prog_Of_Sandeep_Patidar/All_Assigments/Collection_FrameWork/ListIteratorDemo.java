import java.util.ArrayList;
import java.util.ListIterator;
class ListIteratorDemo
{
	
	public static void main(String[] args)
	{
		ArrayList<String> a = new ArrayList<String>();
		a.add("January");
		a.add("February ");
		a.add("March");
		a.add("April ");
		a.add("May");
		a.add("June ");
		a.add("July");
		a.add("August");
		a.add("September");
		a.add("October");
		a.add("November");
		a.add("December ");
		System.out.println("By ListIterator ");
		ListIterator li= a.listIterator();
		while(li.hasNext())
		{
			System.out.println(li.next());
		}
	}
}