import java.util.TreeSet;
import java.util.Scanner;
import java.util.Iterator;

class Assig7TreeSet
{
	public static void main(String[] args)
	{
		TreeSet<String> ts = new TreeSet<String>();
		Scanner sc = new Scanner(System.in);
		int i;
		for(i =1; i<= 10; i++)
		{
					System.out.println("Enter the String");
					String st = sc.nextLine();
					ts.add(st);
		}
		System.out.println("The iterator ");
		Iterator t = ts.iterator();
		while(t.hasNext())
		{
			System.out.println(t.next());
		}
		System.out.println(" \t String Find in TreeSet");
		System.out.println("Enter the String to find");
		String st = sc.nextLine();
		boolean a = ts.contains(st);
		if(a == true)
		{
			System.out.println("String " + st + "is Exist in TreeSet" );
		}
		else
		{
	
			System.out.println("String " + st + " is Not Exist in TreeSet" );
		}
		
		
	}
}