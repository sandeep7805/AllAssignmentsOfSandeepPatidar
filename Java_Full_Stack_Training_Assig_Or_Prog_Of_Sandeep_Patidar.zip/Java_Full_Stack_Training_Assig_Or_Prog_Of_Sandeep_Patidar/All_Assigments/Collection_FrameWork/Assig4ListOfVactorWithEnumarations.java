

class Employee
{

}

class Assig4ListOfVactorWithEnumarations extends Employee
{
	
	}
}