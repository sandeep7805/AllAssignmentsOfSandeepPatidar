import java.util.HashSet; 
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.util.Iterator;
import java.util.NoSuchElementException;
class Assig5HashSet
{
	private String country;
	String setCountry(String country)
	{
		this.country = country;
		System.out.println("Country added sucessfully ");
		return country;
	}
	String getCountry()
	{
		return "countryName = " + country ;
	}
	public static void main(String[] args) throws Exception
	{
		HashSet<String> hs =new HashSet<String>(); 
		InputStreamReader ir = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(ir);
		System.out.println("Enetr the size");
		int size  = Integer.parseInt(br.readLine());
		System.out.println();
	
		int i;
		for(i=1; i<=size; i++)
		{
			
			Assig5HashSet h1 = new Assig5HashSet();
			System.out.println("Enter country name");
			String country = br.readLine();
			boolean a  = hs.add(h1.setCountry(country));
			h1.getCountry();
	
		}
		Iterator t = hs.iterator();
		for(String s:hs)
		{
			System.out.println(s);
		}
		
		
			
	}
}