import java.util.Scanner;


public class StringSplit {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the String");
		String s = sc.nextLine();
		String a[] = s.split("\\s");
		for(String w:a)
		{
			System.out.println(w);
		}
		
	}

}
