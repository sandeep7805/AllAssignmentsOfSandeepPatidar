import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MobNumberRegex {
	public static void main(String[] args) {

	Scanner sc = new Scanner(System.in);
	String t1 = "[0-9]{10}";
	System.out.println("Enetr the Number range(10)");
	String num = sc.nextLine();
	boolean b = Pattern.matches(t1,num); 
	if(b)
	{
		System.out.println("Number register sucessfuly");
	}
	else
	{
		System.out.println("Enter only deigit between 10( 0 To 9) register sucessfuly");
	}
	
	
	System.out.println("Enetr the Email");
	String t = "[A-Za-z0-9]+[@][a-z]+[.][a-z]{2,3}";
	String email = sc.nextLine();
	boolean b1 = Pattern.matches(t,email);
	if(b1)
	{
		System.out.println("Email Register sucessfuly");
	}
	else
	{
		System.out.println("Enter only Email sucessfuly");
	}
	

	System.out.println("Enetr the url");
	String t2 = "[http:]+[a-z]*";
	String url = sc.nextLine();
	boolean b2 = Pattern.matches(t2,url);
	if(b2)
	{
		System.out.println("url register sucessfull");
	}
	else
	{
		System.out.println("Enter valid url start with http:");
	}
	}
	}
	
