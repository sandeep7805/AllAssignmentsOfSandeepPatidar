import java.util.regex.*;

class RegexDemo
{
	public static void main(String[] args)
	{
		Pattern pattern = Pattern.compile("a regex");
		Matcher matcher = pattern.matcher("This is a regex programe");
		
		if(matcher.find())
		{
			System.out.println("string found " + matcher.group() + " at index" + matcher.start() + " end index " + matcher.end());
		}
		else
		{
			System.out.println("String not found ");
		}
		
	}
}