class ConstructorDefaultOrPerametize
{
	String name;
	int age ;
	int emp_id;
	public ConstructorDefaultOrPerametize()
	{
		System.out.println("This is a No argument Constructor");
	}
	public ConstructorDefaultOrPerametize(String name, int age ,int emp_id)
	{
		this.name = name;
		this.age = age;
		this.emp_id = emp_id;
		System.out.println("Nmae is =" + name);
		System.out.println("age is = " + age);
		System.out.println("emp_id is = " + emp_id);
	}
	
	public static void main(String[] args)
	{
		ConstructorDefaultOrPerametize ob = new ConstructorDefaultOrPerametize("abc",10,100001);
		ConstructorDefaultOrPerametize ob1 = new ConstructorDefaultOrPerametize();
	}
	
	
}