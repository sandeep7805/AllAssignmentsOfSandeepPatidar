class A
{
	A()
	{
		System.out.println("Class A constructor call");
	}
}
class B extends A
{
	B()
	{
		// By default super call all Constructor call 
		System.out.println("Class B constructor is call");
	}
}
class ConstructorCallBysuper
{
	public static void main(String[] args)
	{
		B obj = new B();
		
	}
	
}