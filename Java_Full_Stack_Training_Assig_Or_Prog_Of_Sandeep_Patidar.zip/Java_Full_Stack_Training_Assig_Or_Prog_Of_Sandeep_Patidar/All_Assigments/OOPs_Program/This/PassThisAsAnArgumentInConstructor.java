class PassThisAsAnArgumentInConstructor
{
	public PassThisAsAnArgumentInConstructor()
	{
		this(10000);
		System.out.println("This is a No Agument Construstor call");
	}	
	public PassThisAsAnArgumentInConstructor(int a)
	{
		int i = a;
		System.out.println("Perametrise constructor call and value of i is =" + i);
	}
	public static void main(String[] args)
	{
	PassThisAsAnArgumentInConstructor ob = new PassThisAsAnArgumentInConstructor();
	}
}