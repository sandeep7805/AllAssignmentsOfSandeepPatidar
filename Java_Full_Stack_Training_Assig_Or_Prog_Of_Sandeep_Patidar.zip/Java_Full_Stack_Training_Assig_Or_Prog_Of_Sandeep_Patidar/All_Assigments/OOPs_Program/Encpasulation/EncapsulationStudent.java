class Student
{   
    private int stu_Id;
	public void setStuData(int stu_Id)
	{
		this.stu_Id = stu_Id;
	}
	public int getStuData()
	{
		return stu_Id;
	}
	
}
class EncapsulationStudent extends Student
{
	public static void main(String[] args)
	{
		EncapsulationStudent obj = new EncapsulationStudent();
		obj.setStuData(1000);
		System.out.println("Student Id is = " + obj.getStuData());
	}
}