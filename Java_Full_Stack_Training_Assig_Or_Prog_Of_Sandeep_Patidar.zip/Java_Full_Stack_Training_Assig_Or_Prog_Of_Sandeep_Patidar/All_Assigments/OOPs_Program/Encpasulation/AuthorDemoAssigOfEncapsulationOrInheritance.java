class Author
{
	private String author_name;
	private String author_Email;
	private char author_Gender;
	
	public void setAuthor(String author_name, String author_Email,char author_Gender)
	{
		this.author_name = author_name;
		this.author_Email = author_Email;
		this.author_Gender= author_Gender;
		
	}
	public void getAuthor()
	{
		System.out.println("Name of author is = " + author_name);
		System.out.println("email of author is = " + author_Email);
		System.out.println("Gender of author is = " + author_Gender);
	}
	public String getAuthoreName()
	{
		return author_name;
	}
}
class Book extends Author
{
	private String book_name;
	private double price;
	private int qunt_in_stock;	
	
	public void setBook(String book_name,double price,int qunt_in_stock)
	{
	this.book_name= book_name;
	this.price = price;
	this.qunt_in_stock = qunt_in_stock;	
	}
	public void getBook(String s)
	{
		System.out.println("Name of Book is =  " + book_name);
		System.out.println("Name of Author is =  " + s);
		System.out.println("price of Book is =  " + price);
		System.out.println("qunt_in_stock of Book is =  " + qunt_in_stock);
		
	}
	
}


class AuthorDemoAssigOfEncapsulationOrInheritance
{
	public static void main(String[] args)
	{
		
		Book obj1 = new Book();
		obj1.setAuthor("Yash","Yash@gmail.com",'M');
		String st = obj1.getAuthoreName();
		obj1.getAuthor();
		obj1.setBook("Technology",109090.0,989697);
		obj1.getBook(st);
		
		
		
	}
}