class Animal
{
	void eat()
	{
		System.out.println("Animal eat mathod is running ");
	}
	void sleep()
	{
		System.out.println("Animal sleep method is running ");
	}
}

class Bird extends Animal
{
	void eat()
	{
		System.out.println("Bird eat mathod is running ");
	}
	void sleep()
	{
		System.out.println("Bird sleep mathod is running ");
	}
	void fly()
	{
		System.out.println("Bird fly mathod is running ");
	}
}
class SingleInheritanceWithOveriding
{
	public static void main(String[] args)
	{
		Animal obj = new Animal();
		obj.eat();
		obj.sleep();
		Bird obj1 = new Bird();
		obj1.eat();
		obj1.sleep();
		obj1.fly();
	}
	
}