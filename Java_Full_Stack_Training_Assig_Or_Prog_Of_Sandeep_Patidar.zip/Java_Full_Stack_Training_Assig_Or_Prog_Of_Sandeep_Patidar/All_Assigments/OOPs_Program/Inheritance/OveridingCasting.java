class Vehical
{
	public String run()
	{
		System.out.println("Vehical is ruuning ");
		return "a";
	}
}
class OveridingCasting extends Vehical
{
	public Object run()
	{
		System.out.println("car is ruuning ");
		return a;
		
	}
	public static void main(String[] args)
	{
		Vehical obj = new Vehical();
		obj.run();
		OveridingCasting obj1 = new OveridingCasting();
		obj1.run();
		obj1.run();
		
	}
}