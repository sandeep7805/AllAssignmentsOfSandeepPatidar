class ShapeHerarchicalInheritanceAndOverrideng
{
	void draw()
	{
		System.out.println("Drawing shape");
	}
	void erase()
	{
		System.out.println("Erasing shape");
	}

}
class Circle extends ShapeHerarchicalInheritanceAndOverrideng
{
	void draw()
	{
		System.out.println("drawing  Circle");
	}
	void erase()
	{
		System.out.println("Erasing Circle");
	}

}
class Triangle extends ShapeHerarchicalInheritanceAndOverrideng 
{
	void draw()
	{
		System.out.println("drawing  Triangle");
	}
	void erase()
	{
		System.out.println("Erasing Triangle");
	}

}
class Square extends ShapeHerarchicalInheritanceAndOverrideng
{
	void draw()
	{
		System.out.println("drawing  Square");
	}
	void erase()
	{
		System.out.println("Erasing Square");
	}

}
class Run
{
	public static void main(String[] args)
	{
		ShapeHerarchicalInheritanceAndOverrideng obj = new ShapeHerarchicalInheritanceAndOverrideng();
		obj.draw();
		obj.erase();
		
		ShapeHerarchicalInheritanceAndOverrideng obj1 = new Circle();
		obj1.draw();
		obj1.erase();
		
		ShapeHerarchicalInheritanceAndOverrideng obj2 = new Triangle();
		obj2.draw();
		obj2.erase();
		
		ShapeHerarchicalInheritanceAndOverrideng obj3 = new Square();
		obj3.draw();
		obj3.erase();
		
		
		
	}	
}