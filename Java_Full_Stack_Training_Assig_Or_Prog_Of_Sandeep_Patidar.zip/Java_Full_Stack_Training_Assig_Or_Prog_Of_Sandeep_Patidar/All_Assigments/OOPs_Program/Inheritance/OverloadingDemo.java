class Overloding
{
	void display()
	{
		System.out.println("Display first Method ");
	}
	void display(int a)
	{
		System.out.println("Display first Method2 " + a);
	}
	void display(String s,int a)
	{
		System.out.println("Display first Method3 "+  s + "\t" + a);
	}
	void display(int a,String s)
	{
		System.out.println("Display first Method4 " + a + "\t" + s);
	}
	
}
class OverloadingDemo
{
	public static void main(String[] args)
	{
		Overloding obj = new Overloding();
		obj.display();
		obj.display(100);
		obj.display("Abc",100);
		obj.display(100,"Abc");
		
		
	}
}