class Animal
{
	void eat()
	{
		System.out.println("I am eating");
	}
	public static void main(String[] args)
	{
		System.out.println("This is main method of Animal class");
		Animal obj = new Animal();
		obj.eat();
		
	}

}