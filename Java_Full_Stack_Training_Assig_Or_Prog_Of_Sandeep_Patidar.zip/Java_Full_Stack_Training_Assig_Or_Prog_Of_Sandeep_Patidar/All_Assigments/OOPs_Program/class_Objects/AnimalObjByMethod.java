class AnimalObjByMethod
{
	String color;
	int age;
	void intinOb(String s,int a)
	{
		color = s;
		age = a;
	}
	void displey()
	{
		System.out.println(color + " " +age);
	}
	public static void main(String[] args)
	{
		System.out.println("This is main method of Animal class");
		AnimalObjByMethod obj = new AnimalObjByMethod();
		obj.intinOb("white" , 90);
		obj.displey();
	}

}