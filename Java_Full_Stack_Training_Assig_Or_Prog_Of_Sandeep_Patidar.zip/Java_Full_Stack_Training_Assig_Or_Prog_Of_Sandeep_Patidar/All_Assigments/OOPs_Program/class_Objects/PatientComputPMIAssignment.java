class PatientComputPMIAssignment
{
	String name;
	double height;
	double width;
	double pmi;
	double computePMI(String name,double width,double height)
	{
		this.name = name;
		this.height = height;
		this.width = width;
		pmi = (width/height)*height;
		System.out.println("PMI of patient " + name + " is = " + pmi );
		return pmi;
	}
	public static void main(String[] args)
	{
		PatientComputPMIAssignment obj = new PatientComputPMIAssignment();
		obj.computePMI("abc",15,3);
	}

}