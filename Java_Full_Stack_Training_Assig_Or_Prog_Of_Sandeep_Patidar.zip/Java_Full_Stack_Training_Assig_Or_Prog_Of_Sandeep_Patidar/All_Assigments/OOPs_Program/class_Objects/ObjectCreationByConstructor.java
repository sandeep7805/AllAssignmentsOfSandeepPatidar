class ObjectCreationByConstructor
{
	int a;
	ObjectCreationByConstructor(int a)
	{
		System.out.println("This is a valu of a = " + a);
	}
	public static void main(String[] args)
	{
		ObjectCreationByConstructor obj = new ObjectCreationByConstructor(99);
	}
}