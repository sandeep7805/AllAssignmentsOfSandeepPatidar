import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.util.Scanner;
abstract interface LibraryUser
{
	void registerAccount(int age);
	void requestBook(String book);
}
class KidsUser implements LibraryUser
{
	int age;
	String bookType;
	public void registerAccount(int age)
	{
		this.age = age;
		if(age < 12)
			{
				System.out.println("You have sucessfully register in Kids Account");
			}
		else
			{
				System.out.println("Sorry , Age must be less then 12");
			}
		
	}
	public void requestBook(String book)
	{
		this.bookType = book;
		if(bookType.equals("kids"))
		{
			System.out.println("Kids Book issu sucessfully please return book within 10 days");
		}
		else
		{
			System.out.println("Oops You are allow only kids book");
		}
	}
	
}
class AdultUser implements LibraryUser
{
	int age;
	String bookType;
	public void registerAccount(int age)
	{
		this.age = age;
		if(age > 12)
			{
				System.out.println("You have sucessfully register in Adults Account");
			}
		else
			{
				System.out.println("Sorry , Age must be Greater then 12");
			}
		
	}
	public void requestBook(String book)
	{
		this.bookType = book;
		if(bookType.equals("Fiction"))
		{
			System.out.println("Fiction Book issu sucessfully please return book within 7 days");
		}
		else
		{
			System.out.println("Oops You are allow only adults fictions book");
		}
	}
	
}


class LibraryInterfacedemo
{
	public static void main(String[] args)throws Exception
	{
		InputStreamReader r = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(r);
		Scanner sc = new Scanner(System.in);
		
		
		
		System.out.println("Enter the age ");
		int age = Integer.parseInt((br.readLine()));
		
		System.out.println("Enter the book ");
		String bookType= sc.nextLine();
		
		
		
		KidsUser kidsobj = new KidsUser();
		kidsobj.registerAccount(age);
		kidsobj.requestBook(bookType);


		System.out.println();
		
		AdultUser adultobj = new AdultUser();
		adultobj.registerAccount(age);
		adultobj.requestBook(bookType);
		

	}
	
}