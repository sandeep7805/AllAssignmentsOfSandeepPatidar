import java.time.*;
public class JodaTimeDemo4UsaTimZone {
	
	public static void main(String[] args) throws Exception{

		ZoneId zone = ZoneId.systemDefault();
		System.out.println("Local tme Zone is= " + zone);
		
		LocalDateTime dt = LocalDateTime.now();
		System.out.println("Local date and Time is = " + dt);
		
		ZoneId zone1= ZoneId.of("America/California");
		
		ZonedDateTime zt = ZonedDateTime.now(zone1);
		System.out.println("In America = " + zt);
	}
	
}
