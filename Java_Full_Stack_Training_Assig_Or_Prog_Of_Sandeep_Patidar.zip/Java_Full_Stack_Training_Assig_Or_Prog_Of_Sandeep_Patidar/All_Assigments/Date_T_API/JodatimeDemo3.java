import java.time.LocalDateTime;
import java.time.Month;

public class JodatimeDemo3 {
public static void main(String[] args) {
	LocalDateTime dt = LocalDateTime.now();
	System.out.println("current Date and time is " + dt);
	
	LocalDateTime dt1 = LocalDateTime.of(1999,Month.JANUARY,15,11,30);
	System.out.println("Local date and time of object dt1 i s= " + dt1);
	
	System.out.println("7 months from now " + dt1.plusMonths(7));
	System.out.println("day of after 7 months from now =" + dt1.getDayOfWeek());
	System.out.println("gate value of the day of year  after 7 months from now =" + dt1.getDayOfYear());
	
	
}
}
