import java.time.*;
public class JodaTimeDemo2 {
	public static void main(String[] args) {
		
		//Sparate By using Method Of LocalDate Class
		LocalDate date = LocalDate.now();
		int dd = date.getDayOfMonth();
		int mm = date.getMonthValue();
		int yyyy = date.getYear();
		
		System.out.println(dd + "/" + mm  +"/" + yyyy);
		LocalTime time = LocalTime.now();
		int h = time.getHour();
		int m = time.getMinute();
		int s = time.getSecond();
		int n = time.getNano();
		System.out.println(h +":"+ m +":" + s + ":" + n);
	}

}
