import java.time.*;
public class JodaTimDemo {
	// By joda-time API
	public static void main(String[] args) {
		LocalDate today = LocalDate.now();
		LocalTime time = LocalTime.now();
		System.out.println("Date of today is =" + today);
		System.out.println("time of today is =" + time);
		
		
	}

}
