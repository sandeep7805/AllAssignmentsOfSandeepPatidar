import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
class InputOutputStream
{
	public static void main(String[] args)
	{
		FileInputStream f_in = null;
		FileOutputStream f_out=null;
		try
		{
			f_in = new FileInputStream("C:/Users/Sandeep.D/Desktop/FileIO/abc.txt");
			f_out = new FileOutputStream("C:/Users/Sandeep.D/Desktop/FileIO/filewrieread.txt");
			int ch ;	
		
			while((ch = f_in.read()) != -1)
			{
				f_out.write(ch);
				System.out.print((char) ch);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try{
				f_in.close();
				f_out.close();
			}
			catch(IOException e)
			{
				e.printStackTrace();
			}
		}
		
	}
	
}