import java.io.FileInputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;

class ByteArrayInputStreamDemo
{
	public static void main(String[] args) throws IOException
	{
	
		FileInputStream file1 = new FileInputStream("C:/Users/Sandeep.D/Desktop/FileIO/bytearry3.txt");
		byte arry[] = new byte[];
		ByteArrayInputStream bytarry = new ByteArrayInputStream(byte[] file1);
		int i;
		while((i= file1.read()) != -1)
		{
		
			System.out.print(i);
		
		}		
		file1.close();
	
		bytarry.close();
		
	}
}