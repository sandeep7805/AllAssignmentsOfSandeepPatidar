import java.io.File;
class FileExistDemo
{
public static void main(String[] args)
{	
File f = new File("C:/Users/Sandeep.D/Desktop/FileIO/abc.txt");
System.out.println(f.exists());
}
}