import java.io.File;
import java.io.FileInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.FileOutputStream;
class ByteArrayOutputStreamDemo
{
	public static void main(String[] args) throws IOException
	{
		File file1 = new File("C:/Users/Sandeep.D/Desktop/FileIO/bytearry3.txt");
		file1.createNewFile();
		File file2 = new File("C:/Users/Sandeep.D/Desktop/FileIO/bytearry4.txt");
		file2.createNewFile();
		FileInputStream file3 = new FileInputStream("C:/Users/Sandeep.D/Desktop/FileIO/abc.txt");
		FileOutputStream file4 = new FileOutputStream("C:/Users/Sandeep.D/Desktop/FileIO/bytearry3.txt");
		FileOutputStream file5 = new FileOutputStream("C:/Users/Sandeep.D/Desktop/FileIO/bytearry4.txt");
		ByteArrayOutputStream bytarry = new ByteArrayOutputStream();
		int i;
		while((i= file3.read()) != -1)
		{
			
				bytarry.write(i);
				bytarry.writeTo(file4);
				bytarry.writeTo(file5);
				bytarry.reset(); // we need to always reset count 
		
		}		
		file3.close();
		file4.close();
		file4.close();
		file5.close();
		bytarry.close();
		
	}
}