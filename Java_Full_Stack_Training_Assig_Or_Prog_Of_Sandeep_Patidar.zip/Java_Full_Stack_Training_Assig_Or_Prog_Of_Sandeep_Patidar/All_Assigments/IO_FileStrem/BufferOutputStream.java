import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.FileInputStream;
class BufferOutputStream
{
	public static void main(String[] args)
	{
		try
		{
			FileInputStream fin = new FileInputStream("C:/Users/Sandeep.D/Desktop/FileIO/abc.txt");
			FileOutputStream fout = new FileOutputStream("C:/Users/Sandeep.D/Desktop/FileIO/filewrieread.txt"); 
			BufferedOutputStream b_output = new BufferedOutputStream(fout);
			int i;
			while((i = fin.read()) != -1)
				{
					b_output.write((char)i);

				}
			b_output.close();
			fin.close();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			
		}


	}
}