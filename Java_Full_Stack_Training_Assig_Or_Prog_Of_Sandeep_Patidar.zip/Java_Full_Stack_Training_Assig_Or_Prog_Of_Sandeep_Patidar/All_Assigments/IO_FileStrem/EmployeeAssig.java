import java.util.Scanner;
import java.io.ObjectOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.FileOutputStream;
import java.io.Serializable;


class EmployeeAssig implements Serializable
{
	private String name;
	private String department;
	private String designation;
	private double salary;
	public void getEmployee( String name,String department,String designation,double salary)
	{
		this.name=name;
		this.department = department;
		this.designation = designation;
		this.salary=salary;
	}
	public String getEmployee()
	{
		return name + " \t " + department + "\t" + designation + "   \t "+ salary;
	}
	
	public static void main(String[] args) throws IOException,ClassNotFoundException
	{	
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the name");
		String name = sc.nextLine();
		System.out.println("Enter the department");
		String department = sc.nextLine();
		System.out.println("Enter the designation");
		String designation = sc.nextLine();
		System.out.println("Enter the salary");
		double salary = sc.nextDouble();
		
		EmployeeAssig e = new EmployeeAssig();
		e.getEmployee(name, department, designation, salary);
		e.getEmployee();
		
		File file = new File("C:/Users/Sandeep.D/Desktop/FileIO/yash.txt");
		file.createNewFile();
		ObjectOutputStream oosf= new ObjectOutputStream(new FileOutputStream(file));
		oosf.writeObject(e);
		oosf.close();
		
	
		
		
		
	
		
	}

}