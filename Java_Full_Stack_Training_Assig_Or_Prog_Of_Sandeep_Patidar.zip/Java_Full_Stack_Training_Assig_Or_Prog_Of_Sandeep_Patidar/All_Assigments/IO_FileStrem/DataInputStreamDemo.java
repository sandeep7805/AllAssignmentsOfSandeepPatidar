import java.io.FileInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.EOFException;

class DataInputStreamDemo
{
	public static void main(String[] args) throws Exception,EOFException
	{
		FileInputStream file = new FileInputStream("C:/Users/Sandeep.D/Desktop/FileIO/bytearry3.txt");
		DataInputStream dinput = new DataInputStream(file);
		int i ;
		char c;
		System.out.println("Read value in int value");
		while((i = dinput.read()) != -1)
		{	
			System.out.print(i);
		}
			System.out.println("Read value in int char");
		while((i = dinput.readChar()) != -1)
		{	
			System.out.print((char)i);
		}
		
		file.close();
		dinput.close();
	}
}