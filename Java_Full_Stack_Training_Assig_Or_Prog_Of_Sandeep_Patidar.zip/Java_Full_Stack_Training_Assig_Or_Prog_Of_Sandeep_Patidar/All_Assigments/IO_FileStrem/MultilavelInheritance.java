class A
{
	void displayA()
	{
		System.out.println("Class A display method call");
	}
	
}
class B extends A
{
	void displayB()
	{
		System.out.println("Class B display method call");
	}
	
}
class MultilavelInheritance extends B
{
	void displayC()
	{
		System.out.println("Class C display method call");
	}
	public static void main(String[] args)
	{
		MultilavelInheritance obj = new MultilavelInheritance();
		obj.displayA();
		obj.displayB();
		obj.displayC();
	}
}