static class Outer
{
	
	// Static modifier can not be use in Outer class
	
	class Inner
	{
		void show()
		{
			System.out.println("This is Outer class show");
		}
	}
}
public class OuterStaticDemo
{
	public static void main(String[] args)
	{
		//Outer obj= new Outer();
		Outer.Inner inob = new Outer.Inner();
		inob.show();
	}
}