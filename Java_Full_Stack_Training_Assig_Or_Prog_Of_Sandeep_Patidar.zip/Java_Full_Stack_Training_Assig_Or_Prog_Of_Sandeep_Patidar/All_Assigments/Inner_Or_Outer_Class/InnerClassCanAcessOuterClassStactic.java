class A
{
	int a = 5;
	int b = 4;
		
		static class B
			{
				int sum(int f,int s)
				{
					int add = f + s;
					System.out.println("Add is = " + add);
					return add;
				}
			}
}
public class InnerClassCanAcessOuterClassStactic
{
	public static void main(String[] args)
	{
		A obja = new A();
		A.B objb = obja.new B();
		int f = obja.a;
		int s = obja.b;
		objb.sum(f,s);
		
	}
}