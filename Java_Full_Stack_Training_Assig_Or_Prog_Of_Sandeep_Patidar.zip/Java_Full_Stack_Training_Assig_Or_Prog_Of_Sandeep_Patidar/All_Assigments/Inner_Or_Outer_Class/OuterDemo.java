class Outer
{
	static class Inner
	{
		void show()
		{
			System.out.println("This is Outer class show");
		}
	}
}
public class OuterDemo
{
	public static void main(String[] args)
	{
		//Outer obj= new Outer();
		Outer.Inner inob = new Outer.Inner();
		inob.show();
	}
}