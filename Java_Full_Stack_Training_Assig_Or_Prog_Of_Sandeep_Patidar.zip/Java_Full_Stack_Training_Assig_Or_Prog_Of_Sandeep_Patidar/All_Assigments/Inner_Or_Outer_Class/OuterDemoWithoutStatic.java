class Outer
{
	class Inner
	{
		void show()
		{
			System.out.println("This is inner class show without ststic");
		}
	}
}
public class OuterDemoWithoutStatic
{
	public static void main(String[] args)
	{
		Outer obj= new Outer();
		Outer.Inner inob = obj.new Inner();
		inob.show();
	}
}