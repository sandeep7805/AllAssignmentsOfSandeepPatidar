class Outer
{
	
	void show()
	{
		System.out.println("This is Outer class show");
	}
	
	class Inner
	{
		void show()
		{
			System.out.println("This  Ineer class show");
		}
	}
}
public class OuterDemoShowMethodCallOuter
{
	public static void main(String[] args)
	{
		Outer obj= new Outer();
		Outer.Inner inob = new Outer.Inner();
		inob.show();
	}
}