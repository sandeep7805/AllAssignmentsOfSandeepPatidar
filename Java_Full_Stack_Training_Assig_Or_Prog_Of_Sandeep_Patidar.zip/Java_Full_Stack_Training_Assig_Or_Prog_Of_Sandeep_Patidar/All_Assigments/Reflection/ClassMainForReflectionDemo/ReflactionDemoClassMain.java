package ClassMainForReflectionDemo;



public class ReflactionDemoClassMain {
	
	int a = 4;
	int b = 5;
	public void sum()
	{
		System.out.println("Sum is =" + (a + b));
	}
	public ReflactionDemoClassMain() {
		System.out.println("This is ReflactionDemoClassMain Constroctor ");
	}
	
	public static void main(String[] args)
	{
		ReflactionDemoClassMain obj = new ReflactionDemoClassMain();
		obj.sum();
		
	}

}
