package ClassMainForReflectionDemo.Reflection;
import java.lang.Class;
import java.lang.reflect.Method;
import java.util.Arrays;




public class ClassDemoReflection {
	public static void main(String[] args) throws Exception
	{
		Class c = Class.forName("ClassMainForReflectionDemo.ReflactionDemoClassMain");
		System.out.println("value of c is = " + c);
		
		System.out.println("From The get class method is =" +c.getClass());
		
		
		
		Method[] methods = c.getDeclaredMethods();
		System.out.println("the method in class c is = " + Arrays.toString(methods));
		
	
	}
	

}
