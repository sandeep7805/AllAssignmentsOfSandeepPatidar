package com.reflection;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Arrays;

public class TestReflection {
	
		public static void main(String[] args)
		{
			try
			{
				Class c = Class.forName("com.reflection.Reflection");
				System.out.println("Class = " + c);
				System.out.println();
				
				
				Constructor<?>[] constructors = c.getDeclaredConstructors();
				System.out.println("Constructor is= " + Arrays.toString(constructors));
				
				Method[] methods = c.getMethods();
				System.out.println("Methods is =" + Arrays.toString(methods));
				
				Field[] fields = c.getDeclaredFields();
				System.out.println("Fields is =" + Arrays.toString(fields));
				
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}	
		}
			
			
}
