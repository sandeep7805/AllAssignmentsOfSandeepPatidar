package com.reflection;
class A{}
interface B{}

public class ForNameDemo {
public static void main(String[] args) throws Exception 
{
	Class c = Class.forName("A");
	System.out.println(c.isInterface());
	Class c1 = Class.forName("B");
	System.out.println(c1.isInterface());
	}

}
