package com.reflection;

public class Reflection
{
	String name;
	int id;
	Reflection()
	{
		System.out.println("This is Reflaction consructor" );	
	}
	public void rData(String name,int id)
	{
		this.name = name;
		this.id = id;
	}
	public void rShowData()
	{
		System.out.println("name is = " + name);
		System.out.println("id is = " + id);
	}
	public static void main(String[] args)
	{
		Reflection obj = new Reflection();
		obj.rData("Abc", 99);
		obj.rShowData();
	}
	
}
