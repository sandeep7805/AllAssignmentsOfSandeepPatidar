class A{}
class B{}
class IsPrimitiveDemo
{
	public static void main(String[] args) throws Exception
	{
		Class c = Class.forName("A");
		System.out.println("Class A =" + c.isPrimitive());
		Class c1 = Class.forName("B");
		System.out.println("Class B =" + c1.isPrimitive());
	}
}