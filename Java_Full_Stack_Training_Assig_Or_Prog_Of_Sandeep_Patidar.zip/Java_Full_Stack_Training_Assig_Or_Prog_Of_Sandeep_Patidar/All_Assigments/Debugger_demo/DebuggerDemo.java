
public class DebuggerDemo
{
	
	public static void main(String[] args)
	{
		System.out.println("This is a java Debugger class in spring tool suite");
	}
	
	

}
