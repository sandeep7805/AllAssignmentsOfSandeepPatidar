
public class ForLoop {
	public static void main(String[] args)
	{
		int i;
		for(i =0; i <= 10; i++)
		{
			if(i%2 ==0)
			{
				System.out.println("Even NUmber");
			}
			else
			{
				System.out.println("Odd Number");
			}
		}
	}

}
