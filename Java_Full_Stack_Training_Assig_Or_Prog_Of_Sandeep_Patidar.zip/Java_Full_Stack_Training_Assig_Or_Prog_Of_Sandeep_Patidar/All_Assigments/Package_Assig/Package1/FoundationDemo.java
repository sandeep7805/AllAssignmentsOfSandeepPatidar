import testpackage.Foundation;
class FoundationDemo
{
	public static void main(String[] args)
	{
		Foundation obj = new Foundation();
			System.out.println("a is = " + obj.a);// a is private in Foundation can not accses
			System.out.println("b is = " +  obj.b);// b is not public in Foundation ,can not accses
			System.out.println("c is = " + obj.c);// c is protected not accses outside Package 
			System.out.println("d is = " + obj.d);
	}
}