package com.automobile.twoweheeler;
import com.automobile.Vehicle; 
class Hero extends Vehicle
{
	public String getModelName()
	{
		System.out.println("This is get model methodhero class");
		return "Abc";
		
	}
	public String getRegistrationNumber()
	{
		System.out.println("This is getRegister method of hero class");
		return "999999";

	}
	public String getOwenerName()
	{
		System.out.println("This is getOwnerName of hero class");
		return "abc";

	}
	public int getSpeed()
	{
		System.out.println("This is getSpeed method of hero The Speed of Bike is 190 KM/h");
		return 99;

	}
	public void radio()
	{
		System.out.println("This is radio model method of hero class ");
	}
} 
class Honda extends Vehicle
{
	
	public String getModelName()
	{
		System.out.println("This is get model method honda class");
		return "Abc";
		
	}
	public String getRegistrationNumber()
	{
		System.out.println("This is getRegister method of honda class");
		return "999999";

	}
	public String getOwenerName()
	{
		System.out.println("This is getOwnerName of honda class");
		return "abc";

	}
	public int getSpeed()
	{
		System.out.println("This is getSpeed method of honda The Speed of Bike is 190 KM/h");
		return 99;

	}
	public void cdPlayer()
	{
		System.out.println("This is cdPlayer model method of honda ");
	}
} 
public class TestRun
{
	public static void main(String[] args)
	{
		System.out.println("This is a hero class");
		Hero hobj = new Hero();
		hobj.getModelName();
		hobj.getOwenerName();
		hobj.getRegistrationNumber();
		hobj.getSpeed();
		hobj.radio();
		System.out.println();
		System.out.println("This is a honda class");
		Honda hdobj = new Honda();
		hdobj.getModelName();
		hdobj.getOwenerName();
		hdobj.getRegistrationNumber();
		hdobj.getSpeed();
		hdobj.cdPlayer();
		
		
	}
}